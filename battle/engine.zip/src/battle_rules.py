"""간단한 특성·도구 효과 규칙 로더.

프로그램 시작 후 최초 조회 때 JSON을 한 번만 읽고 메모리에 캐시한다.
복잡한 전투 조건이 필요한 효과는 이 파일이 아니라 battle_model.py에서 처리한다.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RULE_DIR = ROOT / "data" / "battle_rules"


def _normalize(value: str) -> str:
    return (value or "").strip().casefold()


@lru_cache(maxsize=1)
def _ability_rules() -> dict[str, dict]:
    return _load_indexed("abilities.json")


@lru_cache(maxsize=1)
def _item_rules() -> dict[str, dict]:
    return _load_indexed("items.json")


def _load_indexed(filename: str) -> dict[str, dict]:
    path = RULE_DIR / filename
    try:
        with path.open(encoding="utf-8") as f:
            raw = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"배틀 규칙 파일을 읽을 수 없습니다: {path}") from exc
    return {_normalize(name): rule for name, rule in raw.items() if not name.startswith("_")}


def ability_rule(name: str) -> dict:
    return _ability_rules().get(_normalize(name), {})


def item_rule(name: str) -> dict:
    return _item_rules().get(_normalize(name), {})
