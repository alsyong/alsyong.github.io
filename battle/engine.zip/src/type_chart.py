"""
포켓몬 18타입 상성표 (6세대 이후 페어리 타입 포함, 챔피언스도 동일)
공격 타입 -> {방어 타입: 배율} (기재 안 된 조합은 전부 1배)
"""

CHART = {
    "Normal":   {"Rock": 0.5, "Ghost": 0, "Steel": 0.5},
    "Fire":     {"Fire": 0.5, "Water": 0.5, "Grass": 2, "Ice": 2, "Bug": 2, "Rock": 0.5, "Dragon": 0.5, "Steel": 2},
    "Water":    {"Fire": 2, "Water": 0.5, "Grass": 0.5, "Ground": 2, "Rock": 2, "Dragon": 0.5},
    "Electric": {"Water": 2, "Electric": 0.5, "Grass": 0.5, "Ground": 0, "Flying": 2, "Dragon": 0.5},
    "Grass":    {"Fire": 0.5, "Water": 2, "Grass": 0.5, "Poison": 0.5, "Ground": 2, "Flying": 0.5, "Bug": 0.5,
                 "Rock": 2, "Dragon": 0.5, "Steel": 0.5},
    "Ice":      {"Fire": 0.5, "Water": 0.5, "Grass": 2, "Ice": 0.5, "Ground": 2, "Flying": 2, "Dragon": 2, "Steel": 0.5},
    "Fighting": {"Normal": 2, "Ice": 2, "Poison": 0.5, "Flying": 0.5, "Psychic": 0.5, "Bug": 0.5, "Rock": 2,
                 "Ghost": 0, "Dark": 2, "Steel": 2, "Fairy": 0.5},
    "Poison":   {"Grass": 2, "Poison": 0.5, "Ground": 0.5, "Rock": 0.5, "Ghost": 0.5, "Steel": 0, "Fairy": 2},
    "Ground":   {"Fire": 2, "Electric": 2, "Grass": 0.5, "Poison": 2, "Flying": 0, "Bug": 0.5, "Rock": 2, "Steel": 2},
    "Flying":   {"Electric": 0.5, "Grass": 2, "Fighting": 2, "Bug": 2, "Rock": 0.5, "Steel": 0.5},
    "Psychic":  {"Fighting": 2, "Poison": 2, "Psychic": 0.5, "Dark": 0, "Steel": 0.5},
    "Bug":      {"Fire": 0.5, "Grass": 2, "Fighting": 0.5, "Poison": 0.5, "Flying": 0.5, "Psychic": 2, "Ghost": 0.5,
                 "Dark": 2, "Steel": 0.5, "Fairy": 0.5},
    "Rock":     {"Fire": 2, "Ice": 2, "Fighting": 0.5, "Ground": 0.5, "Flying": 2, "Bug": 2, "Steel": 0.5},
    "Ghost":    {"Normal": 0, "Psychic": 2, "Ghost": 2, "Dark": 0.5},
    "Dragon":   {"Dragon": 2, "Steel": 0.5, "Fairy": 0},
    "Dark":     {"Fighting": 0.5, "Psychic": 2, "Ghost": 2, "Dark": 0.5, "Fairy": 0.5},
    "Steel":    {"Fire": 0.5, "Water": 0.5, "Electric": 0.5, "Ice": 2, "Rock": 2, "Steel": 0.5, "Fairy": 2},
    "Fairy":    {"Fire": 0.5, "Fighting": 2, "Poison": 0.5, "Dragon": 2, "Dark": 2, "Steel": 0.5},
}

ALL_TYPES = list(CHART.keys())

TYPE_NAMES_KO = {
    "Normal": "노말", "Fire": "불꽃", "Water": "물", "Electric": "전기", "Grass": "풀",
    "Ice": "얼음", "Fighting": "격투", "Poison": "독", "Ground": "땅", "Flying": "비행",
    "Psychic": "에스퍼", "Bug": "벌레", "Rock": "바위", "Ghost": "고스트", "Dragon": "드래곤",
    "Dark": "악", "Steel": "강철", "Fairy": "페어리",
}


def multiplier(attack_type: str, defender_types) -> float:
    """공격 타입 하나가 방어 포켓몬(타입 1~2개)에게 주는 배율."""
    row = CHART.get(attack_type, {})
    result = 1.0
    for dt in defender_types:
        result *= row.get(dt, 1.0)
    return result


def best_multiplier(attack_types, defender_types) -> float:
    """공격 기술 타입 후보들(예: 내 파티원의 기술 4개 타입) 중 가장 효과적인 배율."""
    if not attack_types:
        return 1.0
    return max(multiplier(t, defender_types) for t in attack_types)


def defensive_profile(defender_types):
    """방어 포켓몬이 각 공격 타입에 대해 몇 배로 맞는지 dict로 반환 (약점 파악용)."""
    return {atk: multiplier(atk, defender_types) for atk in ALL_TYPES}


if __name__ == "__main__":
    # 동작 확인: 한카리아스(드래곤/땅)는 얼음 4배 약점이어야 함
    profile = defensive_profile(["Dragon", "Ground"])
    print("한카리아스 방어 프로필 (드래곤/땅):")
    for t, m in profile.items():
        if m != 1.0:
            print(f"  {t}: {m}배")
