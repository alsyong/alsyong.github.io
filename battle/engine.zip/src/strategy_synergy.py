"""선출 단계용 날씨·필드·벽 전개 시너지 평가.
턴 추적 없이, 선봉 등장 직후 또는 첫 턴 설치 가능성만 다룬다.
"""
from __future__ import annotations

AUTO_ENV = {
    "Drizzle": ("rain", "비"),
    "Drought": ("sun", "쾌청"),
    "Sand Stream": ("sand", "모래바람"),
    "Snow Warning": ("snow", "설경"),
    "Electric Surge": ("electric_terrain", "일렉트릭필드"),
    "Grassy Surge": ("grassy_terrain", "그래스필드"),
    "Misty Surge": ("misty_terrain", "미스트필드"),
    "Psychic Surge": ("psychic_terrain", "사이코필드"),
    "Orichalcum Pulse": ("sun", "쾌청(등장 시)"),
    "Hadron Engine": ("electric_terrain", "일렉트릭필드(등장 시)"),
}

ENV_SPEED_ABILITIES = {
    "rain": {"Swift Swim"},
    "sun": {"Chlorophyll"},
    "sand": {"Sand Rush"},
    "snow": {"Slush Rush"},
    "electric_terrain": {"Surge Surfer"},
}
ENV_BENEFIT_ABILITIES = {
    "rain": {"Swift Swim", "Rain Dish", "Hydration", "Dry Skin"},
    "sun": {"Chlorophyll", "Solar Power"},
    "sand": {"Sand Rush", "Sand Force"},
    "snow": {"Slush Rush", "Ice Body"},
    "electric_terrain": {"Surge Surfer"},
}
ENV_MOVE_TYPES = {
    "rain": {"Water"},
    "sun": {"Fire"},
    "electric_terrain": {"Electric"},
    "grassy_terrain": {"Grass"},
    "psychic_terrain": {"Psychic"},
}
ENV_PENALTY_TYPES = {"rain": {"Fire"}, "sun": {"Water"}}
SCREEN_MOVES = {"Reflect": "리플렉터", "Light Screen": "빛의장막", "Aurora Veil": "오로라베일"}


def automatic_environment(entry: dict):
    return AUTO_ENV.get(entry.get("ability", ""))


def _move_names(entry: dict) -> set[str]:
    return {(m or "").replace("’", "'").replace("‘", "'").strip() for m in entry.get("moves", [])}


def screen_profile(entry: dict) -> dict:
    moves = _move_names(entry)
    screens = [ko for en, ko in SCREEN_MOVES.items() if en in moves]
    if not screens:
        return {"screens": [], "bonus": 0.0, "reason": ""}
    bonus = 0.45 + 0.18 * (len(screens) - 1)
    if (entry.get("item") or "").strip().lower() == "light clay":
        bonus += 0.35
    reason = "/".join(screens) + " 설치 가능"
    if (entry.get("item") or "").strip().lower() == "light clay":
        reason += " + 빛의점토"
    return {"screens": screens, "bonus": bonus, "reason": reason}


def member_environment_value(entry: dict, species: dict, env: str) -> tuple[float, list[str]]:
    value, reasons = 0.0, []
    ability = entry.get("ability", "")
    types = set(species.get("types", [])) if species else set()
    move_types = set()
    # 기술 타입은 호출부에서 주입 가능하도록 캐시 필드를 허용한다.
    move_types.update(entry.get("_resolvedMoveTypes", []))

    if ability in ENV_BENEFIT_ABILITIES.get(env, set()):
        value += 0.55
        reasons.append(f"{ability} 활용")
    if ability in ENV_SPEED_ABILITIES.get(env, set()):
        value += 0.25
    boosted = ENV_MOVE_TYPES.get(env, set())
    if types & boosted or move_types & boosted:
        value += 0.28
        reasons.append("강화 타입 활용")
    if env == "sand" and types & {"Rock", "Ground", "Steel"}:
        value += 0.16
        reasons.append("모래바람 적응")
    if env == "snow" and "Ice" in types:
        value += 0.16
        reasons.append("설경 적응")
    if move_types & ENV_PENALTY_TYPES.get(env, set()):
        value -= 0.18
        reasons.append("일부 주력기 약화")
    return value, reasons


def combo_environment_synergy(combo, party, species_list, move_type_resolver) -> tuple[float, list[str]]:
    """조합 안 자동 전개자와 수혜자의 연결을 평가한다."""
    total, notes = 0.0, []
    for lead_i in combo:
        env_info = automatic_environment(party[lead_i])
        if not env_info:
            continue
        env, env_ko = env_info
        beneficiaries = []
        env_value = 0.0
        for i in combo:
            if i == lead_i or not species_list[i]:
                continue
            proxy = dict(party[i])
            proxy["_resolvedMoveTypes"] = move_type_resolver(party[i].get("moves", []))
            value, reasons = member_environment_value(proxy, species_list[i], env)
            if value > 0.1:
                env_value += value
                beneficiaries.append(party[i].get("nickname") or species_list[i].get("nameKo") or party[i]["speciesSlug"])
        if beneficiaries:
            gain = min(1.25, 0.35 + env_value)
            total += gain
            notes.append(f"{env_ko} 전개 → " + ", ".join(beneficiaries) + " 연계")
        else:
            total -= 0.18
            notes.append(f"{env_ko} 자동 전개 수혜자가 조합에 적음")
    return total, notes


def lead_strategy_bonus(index, combo, party, species_list, move_type_resolver) -> tuple[float, list[str]]:
    """개별 선봉 후보의 첫 턴 전개 가치."""
    entry = party[index]
    bonus, reasons = 0.0, []
    env_info = automatic_environment(entry)
    if env_info:
        env, env_ko = env_info
        benefit = 0.0
        names = []
        for i in combo:
            if i == index or not species_list[i]:
                continue
            proxy = dict(party[i])
            proxy["_resolvedMoveTypes"] = move_type_resolver(party[i].get("moves", []))
            val, _ = member_environment_value(proxy, species_list[i], env)
            if val > 0.1:
                benefit += val
                names.append(party[i].get("nickname") or species_list[i].get("nameKo") or party[i]["speciesSlug"])
        bonus += 0.55 + min(1.0, benefit)
        reasons.append(f"등장 즉시 {env_ko} 전개" + (f"로 {', '.join(names)} 지원" if names else ""))

    screens = screen_profile(entry)
    if screens["screens"]:
        # 오로라베일은 같은 조합에 설경 자동 전개자가 있거나 본인이 설경을 전개할 때만 안정적으로 평가.
        if "오로라베일" in screens["screens"]:
            snow_available = any(automatic_environment(party[i]) == ("snow", "설경") for i in combo)
            if not snow_available:
                reduced = max(0.15, screens["bonus"] * 0.35)
                bonus += reduced
                reasons.append("오로라베일 보유(설경 전개가 없어 성공 조건은 불안정)")
            else:
                bonus += screens["bonus"] + 0.2
                reasons.append(screens["reason"] + "(설경 연계 가능)")
        else:
            bonus += screens["bonus"]
            reasons.append(screens["reason"])
    return bonus, reasons
