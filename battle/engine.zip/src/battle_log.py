"""
배틀 결과 기록 + 간단한 학습 반영
----------------------------------
실제로 특정 조합으로 배틀해서 이겼는지 졌는지를 기록해두고,
'내 포켓몬 A가 상대 로스터에 B가 있을 때 실제로 얼마나 잘 이겨왔는지'를
점수에 소폭 반영합니다. 정교한 머신러닝이 아니라, 표본이 쌓일수록
승/패 편차를 완만하게 점수에 더하는 방식입니다 (표본이 적으면 영향 거의 없음).
"""

import json
import os
from datetime import datetime

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(ROOT_DIR, "data", "battle_log.json")

MAX_CONFIDENCE_SAMPLES = 10  # 이 정도 표본이 쌓이면 보정치가 최대로 반영됨
BONUS_SCALE = 1.0            # 보정치 최대 크기 (score_pair의 offense/threat 스케일과 비슷하게)


def _load():
    if not os.path.exists(LOG_PATH):
        return []
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(entries):
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def record_result(my_party_name: str, chosen_slugs, opponent_slugs, lead_slug: str, result: str):
    """result: 'win' 또는 'loss'"""
    assert result in ("win", "loss")
    entries = _load()
    entries.append({
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "my_party": my_party_name,
        "chosen": list(chosen_slugs),
        "opponent": list(opponent_slugs),
        "lead": lead_slug,
        "result": result,
    })
    _save(entries)


def pair_bonus(my_slug: str, opp_slug: str) -> float:
    """my_slug가 선출에 포함되고 opp_slug가 상대 로스터에 있었던 과거 기록들의
    승률 편차(0.5 기준)를 표본 수에 따라 완만하게 반영한 보정치를 반환.
    (파티 구분 없이 전체 기록을 사용 - 같은 포켓몬이면 다른 파티에서 쓰였어도 학습에 반영됨)"""
    entries = _load()
    wins = losses = 0
    for e in entries:
        if my_slug in e.get("chosen", []) and opp_slug in e.get("opponent", []):
            if e["result"] == "win":
                wins += 1
            else:
                losses += 1
    total = wins + losses
    if total == 0:
        return 0.0
    win_rate = wins / total
    confidence = min(total, MAX_CONFIDENCE_SAMPLES) / MAX_CONFIDENCE_SAMPLES
    return (win_rate - 0.5) * 2 * confidence * BONUS_SCALE


def stats_summary(my_party_name: str = None):
    """전체 기록 요약. my_party_name을 주면 그 파티로 진행한 기록만 집계."""
    entries = _load()
    if my_party_name:
        entries = [e for e in entries if e.get("my_party") == my_party_name]
    wins = sum(1 for e in entries if e["result"] == "win")
    losses = sum(1 for e in entries if e["result"] == "loss")
    total = len(entries)
    win_rate = (wins / total * 100) if total else 0.0
    return {"total": total, "wins": wins, "losses": losses, "win_rate": win_rate}


def reset_stats(my_party_name: str = None):
    """기록 초기화. my_party_name을 주면 그 파티 기록만 지우고, 안 주면 전체를 지운다."""
    if my_party_name is None:
        _save([])
        return
    entries = _load()
    remaining = [e for e in entries if e.get("my_party") != my_party_name]
    _save(remaining)
