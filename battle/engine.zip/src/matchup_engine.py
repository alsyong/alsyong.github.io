"""
매치업 스코어링 엔진
--------------------
내 파티 6마리 vs 상대 6마리를 비교해서, 배틀에 선출할 3마리를 추천하고 이유를 문장으로 만든다.
전부 미리 계산해둔 수치(타입 상성/스피드)를 조합해서 문장을 조립하는 방식이라
AI 호출 없이 즉시(수십 ms 이내) 결과가 나온다.
"""

from itertools import combinations

import type_chart
import battle_log
import battle_model
import strategy_synergy
import combo_cohesion
import pikalytics_client
from stat_calc import BaseStats, calc_all_stats, NATURES

STAT_KEYS = ["hp", "atk", "def", "spa", "spd", "spe"]


def normalize_move_name(name):
    return (name or "").replace("’", "'").replace("‘", "'").strip().lower()


def _has_batchim(text: str) -> bool:
    if not text:
        return False
    ch = text[-1]
    return "가" <= ch <= "힣" and (ord(ch) - ord("가")) % 28 != 0


def _with_ro(text: str) -> str:
    """받침과 ㄹ 예외를 반영해 '로/으로'를 붙인다."""
    if not text:
        return text
    ch = text[-1]
    if not ("가" <= ch <= "힣"):
        return text + "로"
    jong = (ord(ch) - ord("가")) % 28
    return text + ("로" if jong in (0, 8) else "으로")


def _with_gwa(text: str) -> str:
    """받침 유무에 맞춰 '과/와'를 붙인다."""
    if not text:
        return text
    return text + ("과" if _has_batchim(text) else "와")


def _join_names(names: list[str]) -> str:
    if not names:
        return ""
    if len(names) == 1:
        return names[0]
    return _with_gwa(names[0]) + " " + ", ".join(names[1:])


def move_display_name(move_name, refdata):
    """영문 기술명을 사용자 표시용 한글명으로 변환한다.

    moves.json에 한글명이 없거나 조회에 실패하면 원래 이름을 그대로 반환한다.
    영문/한글 입력 모두 처리해 자동조회 데이터와 수동 입력을 함께 지원한다.
    """
    key = normalize_move_name(move_name)
    if not key:
        return move_name
    for move in refdata.moves_by_id.values():
        en = (move.get("nameEn") or "").strip().lower()
        ko = (move.get("nameKo") or "").strip()
        if key == en or key == ko.lower():
            return ko or move.get("nameEn") or move_name
    return move_name


def resolve_move_types(move_names, refdata):
    """기술 이름(영문) 리스트 -> 타입 리스트. moves.json에서 못 찾으면 건너뜀.
    대소문자/앞뒤 공백 차이는 무시하고 매칭한다 (Pikalytics 자동조회 표기가 살짝 다를 수 있어서)."""
    name_to_move = {}
    for m in refdata.moves_by_id.values():
        key = normalize_move_name(m.get("nameEn"))
        if key:
            name_to_move[key] = m

    types = []
    for name in move_names:
        m = name_to_move.get(normalize_move_name(name))
        if m and m.get("type"):
            types.append(m["type"])
    return types


def unresolved_moves(move_names, refdata):
    """move_names 중 도감에서 타입을 못 찾은(=계산에서 빠진) 기술 이름 목록."""
    name_to_move = {}
    for m in refdata.moves_by_id.values():
        key = normalize_move_name(m.get("nameEn"))
        if key:
            name_to_move[key] = m
    return [n for n in move_names if n and (normalize_move_name(n) not in name_to_move)]


def estimate_speed_range(species, item):
    """실수치를 정확히 알 수 없는 포켓몬의 '최소(무투자)~최대(32투자+가속성격)' 스피드 범위 추정.
    구애스카프를 들고 있으면 최대치에 1.5배를 추가로 곱한다."""
    level = 50
    min_speed = calc_all_stats(BaseStats.from_dict(species["baseStats"]), {k: 0 for k in STAT_KEYS}, level, "Hardy")["spe"]
    max_points = {k: 0 for k in STAT_KEYS}
    max_points["spe"] = 32
    max_speed = calc_all_stats(BaseStats.from_dict(species["baseStats"]), max_points, level, "Jolly")["spe"]
    if item and "Scarf" in item:
        max_speed = int(max_speed * 1.5)
    return min_speed, max_speed


def speed_relation(my_speed: int, opp_min: int, opp_max: int) -> str:
    if my_speed > opp_max:
        return "always_faster"
    if my_speed <= opp_min:
        return "always_slower"
    return "uncertain"


# 벽 기술(영문명 -> 한글). Confirmed 기술 목록에 이미 있으면 별도 안내를 생략한다.
SCREEN_MOVES_KO = {"Reflect": "리플렉터", "Light Screen": "빛의장막", "Aurora Veil": "오로라베일"}
SCREEN_USAGE_THRESHOLD_PCT = 35.0


def pikalytics_speed_estimate(species, item):
    """Pikalytics에서 파악한 인기 성격/노력치 배분이 있으면 그걸로 만든 참고용 단일 스피드 추정치.
    없거나 조회 실패하면 None. 성격·노력치는 상대의 실제 세팅이 아니라 사이트 집계상 1위
    추정치일 뿐이므로, 참고 문구로만 쓰고 항상빠름/항상느림 판정 자체는 바꾸지 않습니다."""
    slug = species.get("slug")
    if not slug:
        return None
    try:
        data = pikalytics_client.fetch_best_set(slug, allow_network=False)
    except Exception:
        return None
    spread = data.get("topSpread")
    if not spread:
        return None
    nature_info = data.get("topNature")
    nature = nature_info["nature"] if nature_info else "Hardy"
    points = {k: spread.get(k, 0) for k in STAT_KEYS}
    try:
        stats = calc_all_stats(BaseStats.from_dict(species["baseStats"]), points, 50, nature)
    except Exception:
        return None
    speed = stats["spe"]
    if item and "Scarf" in item:
        speed = int(speed * 1.5)
    return {
        "speed": speed,
        "nature": nature,
        "nature_pct": nature_info["percent"] if nature_info else None,
        "spread_pct": spread.get("percent"),
    }


def field_ability_note(opp_entry, refdata):
    """등장 특성의 날씨/필드를 출처에 맞게 안내한다.

    직접 입력한 특성만 확정적으로 표현하고, 자동 보충값은 가능성으로 표현한다.
    반환: (라벨, 문구) 또는 None.
    """
    env_info = strategy_synergy.automatic_environment(opp_entry)
    if not env_info:
        return None
    env_key, env_ko = env_info
    label = "필드" if "terrain" in env_key else "날씨"
    auto = bool(opp_entry.get("abilityAutoFilled"))
    if auto:
        slug = opp_entry.get("speciesSlug", "")
        ability_en = opp_entry.get("ability", "")
        try:
            meta = pikalytics_client.fetch_best_set(slug, allow_network=False)
        except Exception:
            meta = {}
        pct = (meta.get("abilityUsage") or {}).get(ability_en)
        if isinstance(pct, (int, float)):
            return label, f"{env_ko} 전개 특성 채용률 {pct:.0f}% - 선봉 등장 시 자동 전개 가능 (미확정 정보)"
        return label, f"{env_ko} 전개 가능성이 높음 - 선봉 등장 시 자동 전개 가능 (미확정 정보)"
    return label, f"{env_ko} 전개 특성 보유 - 선봉 등장 시 즉시 전개"


def screen_usage_note(opp_entry, refdata):
    """상대의 벽 기술 가능성을 출처에 맞게 안내한다.

    직접 입력 기술만 확정 보유로 표현한다. 자동 보충 기술이나 사용률 자료는
    반드시 미확정 정보로 표시하며, 계산 중에는 네트워크를 새로 조회하지 않는다.
    """
    present = set(opp_entry.get("moves", [])) & set(SCREEN_MOVES_KO)
    if present and not opp_entry.get("movesAutoFilled"):
        names_ko = "/".join(SCREEN_MOVES_KO[m] for m in sorted(present))
        return f"{names_ko} 직접 입력됨 - 선봉으로 나오면 벽을 전개할 수 있음"

    slug = opp_entry.get("speciesSlug", "")
    try:
        data = pikalytics_client.fetch_best_set(slug, allow_network=False)
    except Exception:
        data = {}
    usage = data.get("moveUsage", {})
    hits = [(SCREEN_MOVES_KO[en], pct) for en, pct in usage.items()
            if en in SCREEN_MOVES_KO and pct >= SCREEN_USAGE_THRESHOLD_PCT]
    if hits:
        parts = ", ".join(f"{ko} 채용률 {pct:.0f}%" for ko, pct in hits)
        return f"{parts} - 선봉 벽 전개 가능성 있음 (미확정 정보)"

    if present and opp_entry.get("movesAutoFilled"):
        names_ko = "/".join(SCREEN_MOVES_KO[m] for m in sorted(present))
        return f"{names_ko}가 자동 추천 기술에 포함됨 - 실제 보유 여부 미확정"
    return None


def find_mega_forms(refdata, base_slug: str):
    """base_slug(예: 'charizard')의 메가진화 폼들(예: 'charizard-mega-x/y')을 도감에서 찾아 반환.
    챔피언스 도감 데이터는 메가폼을 별도의 완전한 종(species) 항목으로 갖고 있다는 전제."""
    prefix = base_slug + "-mega"
    return sorted(
        [p for p in refdata.pokemon if p["slug"].startswith(prefix)],
        key=lambda p: p.get("slug", ""),
    )


def _species_ability(species, refdata):
    """종 데이터에 연결된 첫 번째 특성을 (영문명, 한글명, 설명)으로 반환한다."""
    for ability_id in species.get("abilities", []):
        ability = refdata.abilities_by_id.get(str(ability_id))
        if ability:
            return (
                ability.get("nameEn", ""),
                ability.get("nameKo") or ability.get("nameEn", ""),
                (ability.get("descriptionKo") or ability.get("descriptionEn") or "").replace("\n", " ").strip(),
            )
    return "", "", ""


def possible_mega_forms(opp_entry, refdata):
    """상대 정보의 확실성에 따라 실제로 검토해야 할 메가폼 목록을 반환한다.

    - 이미 메가폼 자체를 골랐으면 추가 폼을 붙이지 않는다.
    - 사용자가 정확한 메가스톤을 직접 입력했으면 해당 폼만 사용한다.
    - 빈칸을 사용률 1위로 자동 채운 값이거나 도구를 모르면 모든 폼을 검토한다.
    - 사용자가 메가스톤이 아닌 도구를 직접 입력했으면 메가진화 불가로 본다.
    """
    slug = opp_entry.get("speciesSlug", "")
    if "-mega" in slug:
        return []
    forms = find_mega_forms(refdata, slug)
    if not forms:
        return []

    item = (opp_entry.get("item", "") or "").strip()
    if item and not opp_entry.get("itemAutoFilled"):
        item_key = item.lower()
        if "ite" in item_key:
            if len(forms) == 1:
                return forms
            if item_key.endswith(" x") or item_key.endswith("ite x"):
                matched = [f for f in forms if f.get("slug", "").endswith("-x")]
                if matched:
                    return matched
            if item_key.endswith(" y") or item_key.endswith("ite y"):
                matched = [f for f in forms if f.get("slug", "").endswith("-y")]
                if matched:
                    return matched
            # 메가스톤인 것은 확실하지만 X/Y를 구분할 수 없는 표기라면
            # 한 폼으로 단정하지 않고 가능한 폼을 모두 검토한다.
            return forms
        # 사용자가 비메가 도구를 직접 확정했다면 메가폼을 가정하지 않는다.
        return []
    return forms


def _entry_for_species(entry, species, refdata):
    """같은 기술 구성으로 다른 폼을 계산할 수 있도록 전투용 항목을 만든다."""
    scenario = dict(entry)
    scenario["speciesSlug"] = species.get("slug", entry.get("speciesSlug", ""))
    ability_en, _, _ = _species_ability(species, refdata)
    if ability_en:
        scenario["ability"] = ability_en
    return scenario


def score_pair_with_mega_scenarios(my_entry, my_species, my_stats,
                                   opp_entry, opp_species, refdata):
    """기본 폼과 가능한 모든 메가폼을 계산하고 가장 위험한 결과를 반환한다.

    추천 자체는 상대의 가능한 형태 중 내 입장에서 점수가 가장 낮은 시나리오를
    기준으로 하되, 화면에는 모든 메가폼의 개별 결과를 함께 보여준다.
    """
    entered_slug = opp_entry.get("speciesSlug", "")
    resolved_slug = opp_species.get("slug", "")

    # 사용자가 X/Y 메가스톤을 직접 확정해 combat_species가 특정 폼으로
    # 해석한 경우에는 기본형과 중복 계산하지 않고 그 폼만 정확한 특성으로 계산한다.
    if resolved_slug != entered_slug and "-mega" in resolved_slug:
        scenario_entry = _entry_for_species(opp_entry, opp_species, refdata)
        pair = score_pair(my_entry, my_species, my_stats, scenario_entry, opp_species, refdata)
        ability_en, ability_ko, ability_desc = _species_ability(opp_species, refdata)
        pair["scenario_name"] = opp_species.get("nameKo", opp_species.get("nameEn", resolved_slug))
        pair["scenario_species_slug"] = resolved_slug
        pair["scenario_is_mega"] = True
        pair["known_mega_form"] = True
        pair["base_scenario_pair"] = {}
        pair["mega_scenarios"] = [{
            "species": opp_species,
            "entry": scenario_entry,
            "pair": pair,
            "ability_en": ability_en,
            "ability_ko": ability_ko,
            "ability_desc": ability_desc,
        }]
        return pair

    base_pair = score_pair(my_entry, my_species, my_stats, opp_entry, opp_species, refdata)
    forms = possible_mega_forms(opp_entry, refdata)
    if not forms:
        base_pair["scenario_name"] = opp_species.get("nameKo", opp_species.get("nameEn", ""))
        base_pair["scenario_species_slug"] = opp_species.get("slug", "")
        base_pair["mega_scenarios"] = []
        return base_pair

    mega_scenarios = []
    candidates = [(opp_species, opp_entry, base_pair)]
    for form in forms:
        scenario_entry = _entry_for_species(opp_entry, form, refdata)
        scenario_pair = score_pair(my_entry, my_species, my_stats, scenario_entry, form, refdata)
        ability_en, ability_ko, ability_desc = _species_ability(form, refdata)
        scenario_pair["scenario_name"] = form.get("nameKo", form.get("nameEn", form.get("slug", "")))
        scenario_pair["scenario_species_slug"] = form.get("slug", "")
        mega_scenarios.append({
            "species": form,
            "entry": scenario_entry,
            "pair": scenario_pair,
            "ability_en": ability_en,
            "ability_ko": ability_ko,
            "ability_desc": ability_desc,
        })
        candidates.append((form, scenario_entry, scenario_pair))

    worst_species, _, worst_pair = min(candidates, key=lambda row: row[2].get("score", 0.0))
    aggregated = dict(worst_pair)
    aggregated["scenario_name"] = worst_species.get("nameKo", worst_species.get("nameEn", ""))
    aggregated["scenario_species_slug"] = worst_species.get("slug", "")
    aggregated["scenario_is_mega"] = "-mega" in worst_species.get("slug", "")
    aggregated["base_scenario_pair"] = base_pair
    aggregated["mega_scenarios"] = mega_scenarios
    return aggregated


def mega_notes(my_stats, my_move_types, opp_entry, opp_species, base_speed_rel, base_offense, refdata):
    """이전 호출부 호환용 메가폼 요약. 모든 폼을 빠짐없이 한 번씩 반환한다."""
    results = []
    forms = possible_mega_forms(opp_entry, refdata)
    if not forms:
        return results

    for mega in forms:
        form_notes = []
        mega_label = mega["nameKo"]
        _, ability_ko, _ = _species_ability(mega, refdata)
        opp_min, opp_max = estimate_speed_range(mega, None)
        mega_speed_rel = speed_relation(my_stats["spe"], opp_min, opp_max)

        if mega_speed_rel != base_speed_rel:
            if mega_speed_rel == "always_slower":
                form_notes.append(f"{mega_label}로 메가진화하면 스피드가 올라가 상대가 먼저 움직일 수 있어요.")
            elif mega_speed_rel == "always_faster":
                form_notes.append(f"{mega_label}로 메가진화해도 스피드는 여전히 내가 더 빨라요.")
            else:
                form_notes.append(f"{mega_label}로 메가진화하면 스피드 관계가 불확실해질 수 있어요.")

        if set(mega.get("types", [])) != set(opp_species.get("types", [])):
            mega_offense = type_chart.best_multiplier(my_move_types, mega["types"]) if my_move_types else 1.0
            if mega_offense != base_offense:
                types_text = "/".join(mega.get("types", []))
                form_notes.append(f"{mega_label}는 타입이 {types_text}로 바뀌어서 내 기술 효율이 달라질 수 있어요.")

        if not form_notes:
            form_notes.append(f"{mega_label} 가능성을 검토했습니다.")
        if ability_ko:
            form_notes[0] = form_notes[0].rstrip(".") + f" (특성: {ability_ko})."
        results.extend(form_notes)
    return results



def _ko_summary(move_eval: battle_model.MoveEval) -> str:
    """첫 타격 특성·도구까지 적용한 결과로 확정/난수 타수를 설명한다."""
    min_fraction = move_eval.hp_fraction_min
    max_fraction = move_eval.hp_fraction_max
    if max_fraction <= 0:
        return "피해 없음"

    if move_eval.first_action_ko_blocked:
        names = move_eval.opening_effect_name or "생존 효과"
        if "탈" in names:
            return "탈이 남아 있어 첫 공격 처치 불가"
        return f"{names} 효과로 1 HP 생존"

    if min_fraction >= 1:
        result = "확정 1타"
    elif max_fraction >= 1:
        result = "난수 1타"
    else:
        result = ""
        for hits in range(2, 6):
            if min_fraction * hits >= 1:
                result = f"확정 {hits}타"
                break
            if max_fraction * hits >= 1:
                result = f"난수 {hits}타"
                break
        if not result:
            result = "5타 이상 필요"

    if move_eval.survival_chance > 0 and max_fraction >= 1:
        result += f" ({move_eval.opening_effect_name} {move_eval.survival_chance * 100:g}% 생존 가능)"
    return result



def _refine_operational_action(my_evals, opp_best, my_speed, opp_speed):
    """상대의 실제 최선 공격 결과를 이용해 변화기 가치를 최종 보정한다."""
    threat_max = opp_best.hp_fraction_max if opp_best and opp_best.category != "변화" else 0.0
    # 내가 더 빠르면 회복/강화를 먼저 실행한 뒤에 상대 공격을 받으므로 "쓰러지기 전에
    # 행동을 마칠 수 있는가"라는 걱정 자체가 없다 - 이 턴 행동은 이미 확정적으로 성공한다.
    # 내가 더 느리면 상대가 먼저 움직이므로, 상대 공격이 즉사급이면 내 변화기는 아예 실행되지
    # 못하고 그대로 쓰러진다 - "쓰러질 위험" 감점은 이 경우에만 실제로 들어맞는다.
    i_am_faster = my_speed > opp_speed
    for ev in my_evals:
        if ev.category != "변화":
            continue
        if ev.operation_kind == "recovery":
            if threat_max >= 1.0 and not i_am_faster:
                ev.utility = max(0.0, ev.utility - 18.0)
                ev.operation_note = "상대가 먼저 움직여 회복하기도 전에 쓰러질 수 있어 여유가 적음"
            elif threat_max >= 1.0:
                ev.utility += 3.0
                ev.operation_note = "내가 더 빨라 회복 자체는 성공하지만, 회복 후에도 상대 공격에 쓰러질 수 있음"
            elif 0 < threat_max <= 0.55:
                ev.utility += 14.0
                ev.operation_note = "상대 공격을 버티면서 체력을 복구해 장기전을 만들 수 있음"
            elif threat_max > 0:
                ev.utility += 3.0
                ev.operation_note = "회복은 가능하지만 받는 피해가 커 반복 사용은 어려움"
        elif ev.operation_kind == "setup":
            if threat_max >= 1.0 and not i_am_faster:
                ev.utility = max(0.0, ev.utility - 20.0)
                ev.operation_note = "상대가 먼저 움직여 강화 전에 쓰러질 위험이 커 첫 행동으로는 부적합함"
            elif threat_max >= 1.0:
                ev.utility = max(0.0, ev.utility - 8.0)
                ev.operation_note = "내가 더 빨라 강화 자체는 성공하지만, 다음 상대 공격에 쓰러질 수 있어 활용할 시간이 없음"
            elif 0 < threat_max <= 0.45:
                ev.utility += 14.0
                ev.operation_note = "한 번의 공격을 안정적으로 버티며 랭크업할 여지가 있음"
            elif threat_max <= 0.7 and threat_max > 0:
                ev.utility += 6.0
                ev.operation_note = "강화 기회는 있으나 체력 손실 위험이 있음"
            elif threat_max > 0.7:
                ev.utility = max(0.0, ev.utility - 6.0)
                ev.operation_note = "강화 턴의 피해 부담이 커 조건부 선택지임"
        elif ev.name == "Will-O-Wisp" and opp_best and opp_best.category == "물리":
            ev.utility += 12.0
            ev.operation_kind = "attack_control"
            ev.operation_note = "화상으로 상대 물리 공격을 약화해 즉사 위험을 낮출 수 있음"
        elif ev.operation_kind == "protect" and threat_max >= 0.7:
            ev.utility += 5.0
            ev.operation_note = "강한 공격과 메가진화 여부를 확인하며 한 턴을 안전하게 넘길 수 있음"

    damaging = [e for e in my_evals if e.category != "변화"]
    statuses = [e for e in my_evals if e.category == "변화"]
    best_damage = max(damaging, key=lambda e: e.utility) if damaging else None
    best_status = max(statuses, key=lambda e: e.utility) if statuses else None
    if best_damage and best_damage.hp_fraction_min >= 1.0 and not best_damage.first_action_ko_blocked:
        return best_damage
    if best_status and (not best_damage or best_status.utility >= max(30.0, best_damage.utility + 8.0)
                        or (best_damage.first_action_ko_blocked and best_status.utility >= best_damage.utility + 8.0)):
        return best_status
    return best_damage or best_status

def score_pair(my_entry, my_species, my_stats, opp_entry, opp_species, refdata):
    """기술 위력/분류/실수치/자속/타입/주요 특성·도구를 반영한 매치업 평가."""
    # 상대 세부 스탯은 알 수 없으므로 공격은 해당 기술 분류에 맞춘 투자형,
    # 방어는 균형 내구형으로 추정한다.
    opp_balanced_stats = battle_model.estimated_stats(opp_species, "balanced")

    opp_move_types = resolve_move_types(opp_entry.get("moves", []), refdata)
    opp_moves_listed = bool(opp_entry.get("moves"))
    opp_threat_unresolved = opp_moves_listed and not opp_move_types

    # 상대 위협 계산은 기술별로 물리/특수 투자형 실수치를 사용한다.
    lookup = battle_model.move_lookup(refdata)
    opp_evals = []
    for name in opp_entry.get("moves", []):
        move = lookup.get(normalize_move_name(name))
        if not move:
            continue
        role = "physical" if move.get("category") == "물리" else "special" if move.get("category") == "특수" else "balanced"
        opp_attack_stats = battle_model.estimated_stats(opp_species, role)
        opp_evals.append(battle_model.evaluate_move(
            move, opp_entry, opp_species, opp_attack_stats,
            my_entry, my_species, my_stats,
            attacker_intimidated=(my_entry.get("ability") == "Intimidate"),
        ))
    opp_best = max(opp_evals, key=lambda e: e.utility) if opp_evals else None

    my_best, my_evals = battle_model.best_action(
        my_entry, my_species, my_stats,
        opp_entry, opp_species, opp_balanced_stats, refdata,
        attacker_intimidated=(opp_entry.get("ability") == "Intimidate"),
    )
    # 상대의 실제 최선 공격 피해를 확인한 뒤 회복기·랭크업·방어의 가치를 보정한다.
    provisional_my_speed = battle_model.effective_speed(my_stats, my_entry)
    provisional_opp_speed = battle_model.effective_speed(battle_model.estimated_stats(opp_species, "physical"), opp_entry)
    my_best = _refine_operational_action(my_evals, opp_best, provisional_my_speed, provisional_opp_speed)
    my_damage_evals = [ev for ev in my_evals if ev.category != "변화"]
    my_damage_best = max(my_damage_evals, key=lambda ev: ev.utility) if my_damage_evals else None

    offense = my_best.type_mult if my_best and my_best.category != "변화" else 1.0
    threat = opp_best.type_mult if opp_best and opp_best.category != "변화" else 1.0

    my_speed = battle_model.effective_speed(my_stats, my_entry)
    opp_speed_stats = battle_model.estimated_stats(opp_species, "physical")
    opp_speed = battle_model.effective_speed(opp_speed_stats, opp_entry)
    if my_speed > opp_speed:
        speed = "always_faster"
    elif my_speed < opp_speed:
        speed = "always_slower"
    else:
        speed = "uncertain"

    record_bonus = battle_log.pair_bonus(my_entry["speciesSlug"], opp_entry["speciesSlug"])
    score = battle_model.matchup_score(
        my_best, opp_best, my_entry, opp_entry, my_speed, opp_speed, record_bonus
    )

    return {
        "opp_species_slug": opp_species.get("slug", opp_entry.get("speciesSlug", "")),
        "opp_species_name": opp_species.get("nameKo", opp_species.get("nameEn", opp_entry.get("speciesSlug", ""))),
        "opp_types": list(opp_species.get("types", [])),
        "offense": offense,
        "threat": threat,
        "speed": speed,
        "record_bonus": record_bonus,
        "score": score,
        "my_move_types": resolve_move_types(my_entry.get("moves", []), refdata),
        "opp_threat_unresolved": opp_threat_unresolved,
        "best_move": move_display_name(my_best.name, refdata) if my_best else None,
        "best_move_en": my_best.name if my_best else None,
        "best_move_category": my_best.category if my_best else None,
        "estimated_damage_pct": round((my_best.hp_fraction * 100), 1) if my_best and my_best.category != "변화" else 0.0,
        "damage_min_pct": round((my_best.hp_fraction_min * 100), 1) if my_best and my_best.category != "변화" else 0.0,
        "damage_max_pct": round((my_best.hp_fraction_max * 100), 1) if my_best and my_best.category != "변화" else 0.0,
        "hit_chance_pct": round((my_best.hit_chance * 100), 1) if my_best and my_best.category != "변화" else 0.0,
        "ko_summary": _ko_summary(my_best) if my_best and my_best.category != "변화" else "",
        "base_damage_min_pct": round((my_best.base_hp_fraction_min * 100), 1) if my_best and my_best.category != "변화" else 0.0,
        "base_damage_max_pct": round((my_best.base_hp_fraction_max * 100), 1) if my_best and my_best.category != "변화" else 0.0,
        "opening_effect_name": my_best.opening_effect_name if my_best and my_best.category != "변화" else "",
        "opening_effect_note": my_best.opening_effect_note if my_best and my_best.category != "변화" else "",
        "first_action_ko_blocked": bool(my_best.first_action_ko_blocked) if my_best and my_best.category != "변화" else False,
        "survival_chance": float(my_best.survival_chance) if my_best and my_best.category != "변화" else 0.0,
        "best_status_utility": my_best.utility if my_best and my_best.category == "변화" else 0.0,
        "operation_kind": my_best.operation_kind if my_best else "",
        "operation_note": my_best.operation_note if my_best else "",
        "damage_option_move": move_display_name(my_damage_best.name, refdata) if my_damage_best else None,
        "damage_option_min_pct": round(my_damage_best.hp_fraction_min * 100, 1) if my_damage_best else 0.0,
        "damage_option_max_pct": round(my_damage_best.hp_fraction_max * 100, 1) if my_damage_best else 0.0,
        "damage_option_base_min_pct": round(my_damage_best.base_hp_fraction_min * 100, 1) if my_damage_best else 0.0,
        "damage_option_base_max_pct": round(my_damage_best.base_hp_fraction_max * 100, 1) if my_damage_best else 0.0,
        "damage_option_ko_summary": _ko_summary(my_damage_best) if my_damage_best else "",
        "damage_option_opening_effect_note": my_damage_best.opening_effect_note if my_damage_best else "",
        "opp_best_move": move_display_name(opp_best.name, refdata) if opp_best else None,
        "opp_best_move_en": opp_best.name if opp_best else None,
        "opp_best_move_type": (lookup.get(normalize_move_name(opp_best.name)) or {}).get("type") if opp_best else None,
        "opp_best_move_category": opp_best.category if opp_best else None,
        "opp_ability": opp_entry.get("ability", ""),
        "estimated_taken_pct": round((opp_best.hp_fraction * 100), 1) if opp_best and opp_best.category != "변화" else 0.0,
        "taken_min_pct": round((opp_best.hp_fraction_min * 100), 1) if opp_best and opp_best.category != "변화" else 0.0,
        "taken_max_pct": round((opp_best.hp_fraction_max * 100), 1) if opp_best and opp_best.category != "변화" else 0.0,
        "taken_ko_summary": _ko_summary(opp_best) if opp_best and opp_best.category != "변화" else "",
        "taken_base_min_pct": round((opp_best.base_hp_fraction_min * 100), 1) if opp_best and opp_best.category != "변화" else 0.0,
        "taken_base_max_pct": round((opp_best.base_hp_fraction_max * 100), 1) if opp_best and opp_best.category != "변화" else 0.0,
        "taken_opening_effect_name": opp_best.opening_effect_name if opp_best and opp_best.category != "변화" else "",
        "taken_opening_effect_note": opp_best.opening_effect_note if opp_best and opp_best.category != "변화" else "",
        "taken_first_action_ko_blocked": bool(opp_best.first_action_ko_blocked) if opp_best and opp_best.category != "변화" else False,
        "taken_survival_chance": float(opp_best.survival_chance) if opp_best and opp_best.category != "변화" else 0.0,
    }


def _fmt_mult(m):
    if m == 0:
        return "무효"
    if m >= 2:
        return f"{m:g}배 (효과가 굉장함)"
    if m <= 0.5:
        return f"{m:g}배 (효과가 별로임)"
    return "1배 (보통)"


def _fmt_pct_range(low: float, high: float) -> str:
    return f"{low:g}%" if abs(low - high) < 0.05 else f"{low:g}~{high:g}%"


def _speed_relation_text(value: str) -> str:
    return {
        "always_faster": "내가 먼저 움직임",
        "always_slower": "상대가 먼저 움직일 가능성이 높음",
        "uncertain": "스피드 관계 불확실",
    }.get(value, "스피드 관계 불확실")


def _mega_scenario_lines(pair_score, refdata):
    """메가진화 계산 결과를 판단 기준·다른 가능성·핵심 차이로 압축해 표시한다."""
    scenarios = pair_score.get("mega_scenarios") or []
    if not scenarios:
        return []

    lookup = battle_model.move_lookup(refdata)
    base = pair_score.get("base_scenario_pair") or {}
    selected_slug = pair_score.get("scenario_species_slug", "")
    selected_name = pair_score.get("scenario_name") or "메가진화 가능 폼"

    # 직접 입력한 메가스톤으로 폼이 확정된 경우
    if pair_score.get("known_mega_form"):
        scenario = scenarios[0]
        ability_ko = scenario.get("ability_ko") or scenario.get("ability_en") or "특성 미확인"
        return [
            f"메가진화 판단 기준: {selected_name}({ability_ko})",
            "다른 가능성: 입력한 메가스톤으로 폼이 확정되어 별도 비교 없음",
            "판단 차이: 해당 메가폼의 타입·능력치·특성을 직접 반영함",
        ]

    opp_slug = ""
    opp_name = "기본형"
    if scenarios:
        first_slug = scenarios[0]["species"].get("slug", "")
        if "-mega" in first_slug:
            opp_slug = first_slug.split("-mega", 1)[0]
    if opp_slug:
        base_species = refdata.get_species(opp_slug)
        if base_species:
            opp_name = f"기본 {base_species.get('nameKo', base_species.get('nameEn', opp_slug))}"

    selected_ability = "특성 미확인"
    alternatives = [opp_name]
    selected_pair = pair_score
    selected_species = None
    for scenario in scenarios:
        species = scenario["species"]
        name = species.get("nameKo", species.get("nameEn", species.get("slug", "")))
        ability_ko = scenario.get("ability_ko") or scenario.get("ability_en") or "특성 미확인"
        if species.get("slug") == selected_slug:
            selected_ability = ability_ko
            selected_pair = scenario["pair"]
            selected_species = species
        else:
            alternatives.append(f"{name}({ability_ko})")

    # 기본형이 판단 기준이면 메가폼만 다른 가능성으로 남긴다.
    if selected_slug == opp_slug:
        selected_ability = "기본 특성"
        alternatives = []
        for scenario in scenarios:
            species = scenario["species"]
            name = species.get("nameKo", species.get("nameEn", species.get("slug", "")))
            ability_ko = scenario.get("ability_ko") or scenario.get("ability_en") or "특성 미확인"
            alternatives.append(f"{name}({ability_ko})")

    differences = []
    base_move_en = base.get("best_move_en")
    base_move = lookup.get(normalize_move_name(base_move_en)) if base_move_en else None
    base_move_type = (base_move or {}).get("type")
    selected_ability_en = ""
    if selected_species is not None:
        selected_ability_en, _, _ = _species_ability(selected_species, refdata)

    if selected_ability_en == "Levitate" and base_move_type == "Ground":
        differences.append(f"기본형 추천 {base.get('best_move') or base_move_en}이 부유로 무효")
    elif selected_ability_en == "No Guard":
        differences.append("노가드로 서로 사용하는 기술이 반드시 명중")
    elif selected_ability_en == "Electric Surge":
        differences.append("등장과 동시에 일렉트릭필드를 전개해 전기 화력이 상승")

    if selected_pair.get("best_move") != base.get("best_move") and base.get("best_move"):
        differences.append(
            f"추천 기술이 {base.get('best_move')}에서 {_with_ro(selected_pair.get('best_move') or '유효 공격 없음')} 변경"
        )
    if selected_pair.get("speed") != base.get("speed"):
        differences.append(f"스피드 판정 변경: {_speed_relation_text(selected_pair.get('speed'))}")

    # 다른 메가폼 중에서도 결론을 크게 바꾸는 요소가 있으면 한 가지만 보충한다.
    for scenario in scenarios:
        species = scenario["species"]
        if species.get("slug") == selected_slug:
            continue
        form_pair = scenario["pair"]
        ability_en = scenario.get("ability_en", "")
        name = species.get("nameKo", species.get("nameEn", species.get("slug", "")))
        if ability_en == "Levitate" and base_move_type == "Ground":
            note = f"{name}는 부유로 {base.get('best_move') or base_move_en}을 무효화"
        elif ability_en == "No Guard":
            note = f"{name}는 노가드로 명중률 변수를 제거"
        elif ability_en == "Electric Surge":
            note = f"{name}는 일렉트릭필드로 전기 화력을 강화"
        elif form_pair.get("best_move") != base.get("best_move") and base.get("best_move"):
            note = f"{name}에서는 추천 기술이 {form_pair.get('best_move') or '유효 공격 없음'}으로 변경"
        elif form_pair.get("speed") != base.get("speed"):
            note = f"{name}에서는 {_speed_relation_text(form_pair.get('speed'))}"
        else:
            continue
        if note not in differences:
            differences.append(note)
        if len(differences) >= 2:
            break

    if not differences:
        differences.append("가능한 폼을 모두 비교했지만 현재 추천 행동은 동일")

    return [
        f"메가진화 판단 기준: {selected_name}({selected_ability})",
        "다른 가능성: " + (", ".join(alternatives) if alternatives else "없음"),
        "판단 차이: " + " / ".join(differences[:2]),
    ]

def build_reasoning_lines(my_entry, opp_entry, pair_score, refdata, lead_entry=None, lead_action=None, pivot_move=None, lead_context=None):
    """상대 1마리에 대한 대처법을 항목별 짧은 문장(리스트)으로 만든다. 화면에서 줄바꿈해서 보여주기 좋음."""
    my_name = refdata.species_display(my_entry["speciesSlug"], my_entry.get("nickname"))
    opp_species = refdata.get_species(opp_entry["speciesSlug"])

    lines = []

    if lead_entry is not None:
        lead_name = refdata.species_display(lead_entry["speciesSlug"], lead_entry.get("nickname"))
        if lead_action == "keep" or (lead_action is None and my_entry["speciesSlug"] == lead_entry["speciesSlug"]):
            keep_kind = (lead_context or {}).get("keep_kind", "favorable")
            if keep_kind == "reluctant":
                lines.append("대응: ⚠ 불리하지만 교체보다 선봉 유지 권장")
                threat_move = pair_score.get("opp_best_move")
                threat_type = pair_score.get("opp_best_move_type")
                threat_type_ko = type_chart.TYPE_NAMES_KO.get(threat_type, threat_type or "상대")
                if threat_move and pair_score.get("taken_max_pct", 0) >= 70:
                    lines.append(f"주의: {opp_species.get('nameKo', opp_entry['speciesSlug'])}의 {threat_move}({threat_type_ko}타입)에 큰 피해를 받을 수 있음")
                alt_names = (lead_context or {}).get("unsafe_alternative_names", [])
                alt_type = (lead_context or {}).get("shared_alternative_threat_type")
                if alt_names and alt_type:
                    alt_type_ko = type_chart.TYPE_NAMES_KO.get(alt_type, alt_type)
                    lines.append(f"교체 판단: {_join_names(alt_names)}도 {alt_type_ko}타입 기술에 약해 교체 위험이 더 큼")
                elif alt_names:
                    lines.append(f"교체 판단: {_with_ro(_join_names(alt_names))} 바꿔도 현재 대면보다 안전해지기 어려움")
                tactical = (lead_context or {}).get("tactical_moves", [])
                if tactical:
                    lines.append(f"운영 선택지: {' 또는 '.join(tactical)} 활용을 고려")
                    burn_reduced = (lead_context or {}).get("burn_reduced_taken_max_pct")
                    if burn_reduced is not None:
                        lines.append(f"도깨비불 성공 시 상대 물리 기술의 예상 최대 피해가 약 {burn_reduced:g}%까지 감소")
                else:
                    lines.append(f"교체 판단: {_with_ro(lead_name)} 현재 대면을 이어가는 편이 상대적으로 안전함")
            else:
                lines.append(f"대응: ✓ 유리하여 선봉({lead_name}) 유지")
        elif lead_action == "pivot" and pivot_move:
            pivot_name = move_display_name(pivot_move.get("nameEn", pivot_move.get("nameKo", "교체 기술")), refdata)
            lines.append(f"대응: 선봉({lead_name})이 {pivot_name} 사용 후 {_with_ro(my_name)} 교체")
        else:
            lines.append(f"대응: 선봉({lead_name}) 대신 {_with_ro(my_name)} 교체 투입")

    if pair_score.get("mega_scenarios"):
        lines.extend(_mega_scenario_lines(pair_score, refdata))

    lines.append(f"공격: 내 기술이 {_fmt_mult(pair_score['offense'])}로 들어감")

    best_move = pair_score.get("best_move")
    if best_move:
        if pair_score.get("best_move_category") == "변화":
            lines.append(f"추천 행동: {best_move} (직접 피해보다 전술적 가치가 높음)")
            operation_note = pair_score.get("operation_note", "")
            if operation_note:
                lines.append(f"운영 효과: {operation_note}")
            effect_note = pair_score.get("damage_option_opening_effect_note", "")
            damage_move = pair_score.get("damage_option_move")
            if effect_note and damage_move:
                base_low = pair_score.get("damage_option_base_min_pct", 0)
                base_high = pair_score.get("damage_option_base_max_pct", 0)
                low = pair_score.get("damage_option_min_pct", 0)
                high = pair_score.get("damage_option_max_pct", 0)
                ko = pair_score.get("damage_option_ko_summary", "")
                base_text = _fmt_pct_range(base_low, base_high)
                final_text = _fmt_pct_range(low, high)
                lines.append(f"상대 생존 효과: {ko}")
                lines.append(f"공격 참고: {damage_move} 기본 {base_text} → 효과 반영 {final_text}")
                lines.append(f"효과 설명: {effect_note}")
        else:
            low = pair_score.get("damage_min_pct", 0)
            high = pair_score.get("damage_max_pct", 0)
            ko = pair_score.get("ko_summary", "")
            hit = pair_score.get("hit_chance_pct", 100)
            hit_note = f" / 명중률 {hit:g}%" if hit < 100 else ""
            damage_text = _fmt_pct_range(low, high)
            lines.append(f"추천 기술: {best_move} (피해 {damage_text} / {ko}{hit_note})")
            operation_note = pair_score.get("operation_note", "")
            if operation_note:
                lines.append(f"운영 효과: {operation_note}")
            effect_note = pair_score.get("opening_effect_note", "")
            if effect_note:
                base_low = pair_score.get("base_damage_min_pct", low)
                base_high = pair_score.get("base_damage_max_pct", high)
                if abs(base_low - low) >= 0.1 or abs(base_high - high) >= 0.1:
                    lines.append(f"특성·도구 반영: {effect_note} (기본 계산 {base_low:g}~{base_high:g}%)")
                else:
                    lines.append(f"특성·도구 반영: {effect_note}")

    if pair_score.get("opp_threat_unresolved"):
        lines.append("방어: 상대 기술 정보를 정확히 몰라 중립(1배)으로 가정함 - 실제로는 다를 수 있음")
    else:
        low = pair_score.get("taken_min_pct", 0)
        high = pair_score.get("taken_max_pct", 0)
        ko = pair_score.get("taken_ko_summary", "")
        threat_move = pair_score.get("opp_best_move")
        suffix = f" / 피해 {_fmt_pct_range(low, high)} / {ko}" if threat_move and high else ""
        lines.append(f"방어: 상대 기술에 {_fmt_mult(pair_score['threat'])}로 맞음{suffix}")
        taken_effect_note = pair_score.get("taken_opening_effect_note", "")
        if taken_effect_note:
            base_low = pair_score.get("taken_base_min_pct", low)
            base_high = pair_score.get("taken_base_max_pct", high)
            if abs(base_low - low) >= 0.1 or abs(base_high - high) >= 0.1:
                lines.append(f"내 생존 효과: {taken_effect_note} (기본 계산 {base_low:g}~{base_high:g}%)")
            else:
                lines.append(f"내 생존 효과: {taken_effect_note}")

    if pair_score["speed"] == "always_faster":
        lines.append("스피드: 항상 내가 먼저 움직임")
    elif pair_score["speed"] == "always_slower":
        lines.append("스피드: 상대가 먼저 움직일 가능성이 높음")
    else:
        lines.append("스피드: 상대 노력치에 따라 달라질 수 있음 (불확실)")
        if opp_species:
            hint = pikalytics_speed_estimate(opp_species, opp_entry.get("item"))
            if hint:
                nature_pct_text = f" ({hint['nature_pct']:g}%)" if hint.get("nature_pct") is not None else ""
                lines.append(
                    f"스피드 참고: Pikalytics 인기 배분 기준 {hint['nature']}{nature_pct_text} 성격이면 "
                    f"약 {hint['speed']} 정도로 추정됨 (미확정 정보)"
                )

    if opp_entry.get("speciesSlug"):
        env_note = field_ability_note(opp_entry, refdata)
        if env_note:
            env_label, env_text = env_note
            lines.append(f"{env_label}: {env_text}")

        note = screen_usage_note(opp_entry, refdata)
        if note:
            lines.append(f"벽 기술: {note}")

    if pair_score.get("record_bonus", 0) >= 0.3:
        lines.append("실전 기록: 이 매치업 승률이 좋았음")
    elif pair_score.get("record_bonus", 0) <= -0.3:
        lines.append("실전 기록: 이 매치업에서 고전했던 적 있음 (주의)")

    return lines


def _lookup_spe(my_entry, refdata):
    """my_entry의 실제 스피드 실수치를 다시 계산 (mega_notes에서 my_stats 전체가 필요 없어 스피드만 뽑음)."""
    species = refdata.get_species(my_entry["speciesSlug"])
    if not species:
        return 0
    stats = calc_all_stats(
        BaseStats.from_dict(species["baseStats"]),
        my_entry.get("abilityPoints", {k: 0 for k in STAT_KEYS}),
        my_entry.get("level", 50),
        my_entry.get("nature", "Hardy"),
    )
    return stats["spe"]


PIVOT_MOVES = {
    "u-turn": "Bug",
    "volt switch": "Electric",
    "flip turn": "Water",
}


def _pivot_move_for(entry, opponent_species, refdata):
    """실제로 입력된 공격형 교체 기술 중 상대에게 통하는 첫 기술을 반환한다."""
    lookup = battle_model.move_lookup(refdata)
    for move_name in entry.get("moves", []):
        key = normalize_move_name(move_name)
        if key not in PIVOT_MOVES:
            continue
        move = lookup.get(key)
        if not move:
            continue
        if type_chart.multiplier(move.get("type"), opponent_species.get("types", [])) <= 0:
            continue
        return move
    return None


def _is_intrinsically_unfavorable(pair_score):
    """교체 후보와 무관하게 현재 선봉 대면 자체가 위험한지 판정한다."""
    taken = pair_score.get("taken_max_pct", 0)
    dealt = pair_score.get("damage_max_pct", 0)
    threat = pair_score.get("threat", 1.0)
    offense = pair_score.get("offense", 1.0)
    return (taken >= 90 and dealt < 100) or (threat >= 2 and offense < 2) or pair_score.get("score", 0) < 0


def _reluctant_keep_context(i, combo, j, matrix, my_party, refdata, opp_species=None):
    """불리하지만 유지하는 이유를 사용자 문장으로 만들기 위한 근거를 정리한다."""
    unsafe = []
    threat_types = []
    for k in combo:
        if k == i or (k, j) not in matrix:
            continue
        p = matrix[(k, j)]
        # 교체 후보도 약점을 찔리거나 현재 선봉보다 더 큰 피해를 받을 때 위험 후보로 본다.
        if p.get("threat", 1.0) >= 2 or p.get("taken_max_pct", 0) >= matrix[(i, j)].get("taken_max_pct", 0):
            unsafe.append(refdata.species_display(my_party[k]["speciesSlug"], my_party[k].get("nickname")))
            if p.get("opp_best_move_type"):
                threat_types.append(p["opp_best_move_type"])
    shared = threat_types[0] if threat_types and all(t == threat_types[0] for t in threat_types) else None
    move_keys = {normalize_move_name(m) for m in my_party[i].get("moves", [])}
    tactical = []
    lead_pair = matrix[(i, j)]
    opponent_types = set((opp_species or {}).get("types", []))
    opponent_ability = lead_pair.get("opp_ability", "")
    wisp_valid = (
        "will-o-wisp" in move_keys
        and "Fire" not in opponent_types
        and opponent_ability not in {"Water Bubble"}
    )
    burn_reduced = None
    if wisp_valid:
        tactical.append("도깨비불")
        if (lead_pair.get("opp_best_move_category") == "물리"
                and lead_pair.get("speed") != "always_slower"
                and opponent_ability != "Guts"):
            burn_reduced = round(lead_pair.get("taken_max_pct", 0) * 0.5, 1)
    if "destiny bond" in move_keys:
        tactical.append("길동무")
    return {
        "keep_kind": "reluctant",
        "unsafe_alternative_names": unsafe,
        "shared_alternative_threat_type": shared,
        "tactical_moves": tactical,
        "burn_reduced_taken_max_pct": burn_reduced,
    }


def _can_stabilize_with_will_o_wisp(i, j, matrix, my_party, opp_species_list) -> bool:
    """빠른 도깨비불로 물리 위협을 즉시 낮출 수 있는 대면인지 본다.

    선출 도우미이므로 다음 턴 전체를 시뮬레이션하지 않고, 첫 행동 전에 화상을
    걸 수 있고 화상 적용 뒤 예상 최대 피해가 100% 미만인 경우만 제한적으로 인정한다.
    """
    pair = matrix.get((i, j))
    if not pair:
        return False
    move_keys = {normalize_move_name(m) for m in my_party[i].get("moves", [])}
    if "will-o-wisp" not in move_keys:
        return False
    if pair.get("speed") == "always_slower":
        return False
    if pair.get("opp_best_move_category") != "물리":
        return False
    opp_species = opp_species_list[j]
    if "Fire" in set(opp_species.get("types", [])):
        return False
    if pair.get("opp_ability") == "Water Bubble":
        return False
    return pair.get("taken_max_pct", 0) * 0.5 < 100


def _lead_matchup_state(i, combo, j, matrix, my_party, opp_species_list, refdata):
    """한 선봉 후보의 상대별 상태를 유지/pivot/switch 중 하나로 분류한다."""
    lead_pair = matrix.get((i, j))
    if not lead_pair:
        return "switch", None
    best_score = max((matrix[(k, j)]["score"] for k in combo if (k, j) in matrix), default=lead_pair["score"])
    # 최적 대응과 큰 차이가 없고 즉사 위험이 지나치지 않으면 그대로 대응 가능.
    competitive = lead_pair["score"] >= best_score - 0.35
    survivable = lead_pair.get("taken_max_pct", 0) < 100 or lead_pair.get("damage_max_pct", 0) >= 100
    if competitive and survivable:
        return "keep", None

    # 모든 교체 후보도 불리한 상황에서는 빠른 도깨비불로 물리 화력을 낮추는 선택을
    # 즉시 교체보다 나은 유지 선택지로 인정한다.
    if best_score < 0 and _can_stabilize_with_will_o_wisp(i, j, matrix, my_party, opp_species_list):
        return "keep", None

    pivot = _pivot_move_for(my_party[i], opp_species_list[j], refdata)
    if pivot:
        # 먼저 움직이거나 한 번은 버틸 가능성이 있을 때만 교체 기술 가치를 인정한다.
        can_act = lead_pair.get("speed") != "always_slower" or lead_pair.get("taken_max_pct", 0) < 100
        if can_act:
            # 내가 더 빠르면 상대가 움직이기 전에 교체가 끝나서, 방금 들어온 후속 포켓몬이
            # 그 턴 상대 공격을 그대로 받는다. 후속 포켓몬이 그 공격을 반감 이하로 받으면
            # (저항) 위험이 크지 않지만, 아니라면 "안전하게 교체"라는 pivot의 장점이 없어져
            # 그냥 즉시 교체(switch)와 다를 게 없다. 내가 더 느리거나 순서가 불확실하면
            # 상대가 이미 그 턴에 행동했거나 아직 안 움직였을 수도 있어 이 노출이 확정이
            # 아니므로 그대로 pivot으로 인정한다.
            if lead_pair.get("speed") == "always_faster":
                alternatives = [k for k in combo if k != i and (k, j) in matrix]
                if alternatives:
                    response_i = max(alternatives, key=lambda k: matrix[(k, j)]["score"])
                    incoming_threat = matrix[(response_i, j)].get("threat", 1.0)
                    if incoming_threat > 0.5:
                        return "switch", None
            return "pivot", pivot
    return "switch", None


def _lead_plan_for_candidate(i, combo, valid_opp_indices, matrix, my_party, opp_species_list, refdata):
    """한 선봉 후보의 상대별 판정을 한 번 계산해 상단 수치와 하단 대처법이 공유하게 한다."""
    plan = {}
    counts = {"keep": 0, "pivot": 0, "switch": 0}
    for j in valid_opp_indices:
        state, pivot = _lead_matchup_state(i, combo, j, matrix, my_party, opp_species_list, refdata)
        counts[state] += 1
        context = {"keep_kind": "favorable"}
        if state == "keep":
            response_i = i
            if _is_intrinsically_unfavorable(matrix[(i, j)]):
                context = _reluctant_keep_context(i, combo, j, matrix, my_party, refdata, opp_species_list[j])
        else:
            alternatives = [k for k in combo if k != i and (k, j) in matrix]
            response_i = max(alternatives, key=lambda k: matrix[(k, j)]["score"]) if alternatives else i
        plan[j] = {"state": state, "pivot": pivot, "response_i": response_i, "context": context}
    return plan, counts


def recommend_lead(combo, matrix, valid_opp_indices, my_party, my_species_list, opp_species_list, refdata):
    """상대별 유지 가능성과 교체 부담까지 포함해 조합 안의 선봉을 추천한다."""
    best_i = None
    best_value = None
    best_counts = None
    best_strategy_reasons = []
    for i in combo:
        scores = [matrix[(i, j)]["score"] for j in valid_opp_indices if (i, j) in matrix]
        if not scores:
            continue
        value = sum(scores) / len(scores)
        strategy_bonus, strategy_reasons = strategy_synergy.lead_strategy_bonus(
            i, combo, my_party, my_species_list, lambda moves: resolve_move_types(moves, refdata)
        )
        value += strategy_bonus

        _, counts = _lead_plan_for_candidate(
            i, combo, valid_opp_indices, matrix, my_party, opp_species_list, refdata
        )
        n = max(1, sum(counts.values()))
        # 유지 가능은 강한 보너스, 교체 기술은 작은 보완, 즉시 교체는 강한 감점.
        value += (counts["keep"] / n) * 0.75
        value += (counts["pivot"] / n) * 0.28
        value -= (counts["switch"] / n) * 0.95
        if counts["switch"] > n / 2 and strategy_bonus < 0.45:
            value -= 0.45

        if best_value is None or value > best_value:
            best_value = value
            best_i = i
            best_counts = counts
            best_strategy_reasons = strategy_reasons

    if best_i is None:
        return None, "", {}

    lead_entry = my_party[best_i]
    lead_name = refdata.species_display(lead_entry["speciesSlug"], lead_entry.get("nickname"))
    n = max(1, sum(best_counts.values()))
    parts = [
        f"상대 {n}마리 중 {best_counts['keep']}마리를 상대로 선봉을 유지할 수 있는 것으로 평가됐습니다."
    ]
    if best_counts["pivot"]:
        parts.append(f"{best_counts['pivot']}마리에게는 교체 기술로 대면을 이어갈 수 있습니다.")
    if best_strategy_reasons:
        parts.extend(best_strategy_reasons[:2])
    return lead_entry, " ".join(parts), best_counts


def score_to_100(raw_score: float, opponent_count: int) -> float:
    """상대 수와 무관하게 읽기 쉬운 고정 100점 척도로 환산한다.

    50점은 대체로 호각인 조합, 100점은 모든 상대에게 매우 우수하고 조합 보정도
    좋은 경우를 뜻한다. 1위 조합을 강제로 100점으로 만드는 상대평가는 아니다.
    """
    scale = max(1.0, opponent_count * 4.5 + 3.0)
    return round(max(0.0, min(100.0, 50.0 + (raw_score / scale) * 50.0)), 1)

def rank_combos(my_party, opponent_party, refdata, pick_count=3, top_n=3):
    """
    my_party / opponent_party: parties/*.json의 "party" 리스트 형태
    반환: {
      "results": [
        {
          "rank": 1,
          "chosen": [my_entry, ...],
          "total_score": float,
          "lead": my_entry 또는 None,
          "lead_reasoning": str,
          "per_opponent": [{"opponent":.., "best_mine":.., "reasoning_lines":[...], "score":..}, ...],
        }, ...
      ],
      "warnings": [str, ...]
    }
    """
    warnings = []

    my_stats_list = []
    my_species_list = []
    for entry in my_party:
        species = battle_model.combat_species(entry, refdata)
        if not species:
            warnings.append(f"{entry.get('nickname', entry['speciesSlug'])}: 도감 데이터에서 찾을 수 없어 계산에서 제외됩니다.")
            my_species_list.append(None)
            my_stats_list.append(None)
            continue
        stats = calc_all_stats(
            BaseStats.from_dict(species["baseStats"]),
            entry.get("abilityPoints", {k: 0 for k in STAT_KEYS}),
            entry.get("level", 50),
            entry.get("nature", "Hardy"),
        )
        my_species_list.append(species)
        my_stats_list.append(stats)

    opp_species_list = []
    for entry in opponent_party:
        species = battle_model.combat_species(entry, refdata)
        if not species:
            warnings.append(f"상대 {entry.get('speciesSlug')}: 도감 데이터에서 찾을 수 없어 계산에서 제외됩니다.")
        opp_species_list.append(species)

    # 상대 기술 이름 중 도감에서 못 찾은 것들을 모아서 한 번만 경고
    unresolved = set()
    for entry in opponent_party:
        for name in unresolved_moves(entry.get("moves", []), refdata):
            unresolved.add(name)
    if unresolved:
        warnings.append(
            "상대 기술 중 도감에서 찾지 못한 것이 있어 방어 계산에서 제외됐습니다: " + ", ".join(sorted(unresolved))
        )

    matrix = {}
    for i, (m_entry, m_species, m_stats) in enumerate(zip(my_party, my_species_list, my_stats_list)):
        if m_species is None:
            continue
        for j, (o_entry, o_species) in enumerate(zip(opponent_party, opp_species_list)):
            if o_species is None:
                continue
            matrix[(i, j)] = score_pair_with_mega_scenarios(
                m_entry, m_species, m_stats, o_entry, o_species, refdata
            )

    valid_my_indices = [i for i, s in enumerate(my_species_list) if s is not None]
    valid_opp_indices = [j for j, s in enumerate(opp_species_list) if s is not None]

    if len(valid_my_indices) < pick_count:
        warnings.append("유효한 내 파티원이 부족해 선출 추천을 완전히 계산할 수 없습니다.")
        pick_count = min(pick_count, len(valid_my_indices))

    scored_combos = []
    for combo in combinations(valid_my_indices, pick_count):
        total = 0.0
        for j in valid_opp_indices:
            total += max(matrix[(i, j)]["score"] for i in combo)
        synergy_adjustment, synergy_notes = battle_model.combo_synergy_adjustment(combo, my_party, my_species_list)
        env_adjustment, env_notes = strategy_synergy.combo_environment_synergy(
            combo, my_party, my_species_list, lambda moves: resolve_move_types(moves, refdata)
        )
        synergy_adjustment += env_adjustment
        synergy_notes.extend(env_notes)
        cohesion_adjustment, cohesion_notes, cohesion_details = combo_cohesion.evaluate_combo(
            combo, my_party, my_species_list, opponent_party, matrix, valid_opp_indices,
            lambda moves: resolve_move_types(moves, refdata), refdata
        )
        synergy_adjustment += cohesion_adjustment
        synergy_notes.extend(cohesion_notes)
        total += synergy_adjustment
        scored_combos.append((total, combo, synergy_adjustment, synergy_notes, cohesion_details))

    scored_combos.sort(key=lambda x: x[0], reverse=True)
    top_combos = scored_combos[:top_n]

    results = []
    for rank, (total, combo, synergy_adjustment, synergy_notes, cohesion_details) in enumerate(top_combos, start=1):
        lead_entry, lead_reasoning, lead_counts = recommend_lead(combo, matrix, valid_opp_indices, my_party, my_species_list, opp_species_list, refdata)
        lead_display = refdata.species_display(lead_entry["speciesSlug"], lead_entry.get("nickname")) if lead_entry else None

        per_opponent = []
        lead_i = next((i for i in combo if my_party[i] is lead_entry), None)
        lead_plan, verified_counts = _lead_plan_for_candidate(
            lead_i, combo, valid_opp_indices, matrix, my_party, opp_species_list, refdata
        ) if lead_i is not None else ({}, {"keep": 0, "pivot": 0, "switch": 0})
        # 상단 설명과 하단 대처법이 반드시 같은 판정 개수를 사용한다.
        lead_counts = verified_counts
        if lead_entry is not None:
            n = max(1, sum(lead_counts.values()))
            reason_parts = [f"상대 {n}마리 중 {lead_counts['keep']}마리를 상대로 선봉을 유지할 수 있는 것으로 평가됐습니다."]
            if lead_counts["pivot"]:
                reason_parts.append(f"{lead_counts['pivot']}마리에게는 교체 기술로 대면을 이어갈 수 있습니다.")
            lead_reasoning = " ".join(reason_parts)

        for j in valid_opp_indices:
            action = lead_plan.get(j, {"state": "switch", "pivot": None, "response_i": max(combo, key=lambda i: matrix[(i, j)]["score"])})
            best_i = action["response_i"]
            pair_score = matrix[(best_i, j)]
            lines = build_reasoning_lines(
                my_party[best_i], opponent_party[j], pair_score, refdata, lead_entry,
                lead_action=action["state"], pivot_move=action["pivot"], lead_context=action.get("context")
            )
            per_opponent.append({
                "opponent": opponent_party[j],
                "opponent_display": refdata.species_display(opponent_party[j]["speciesSlug"], opponent_party[j].get("nickname")),
                "best_mine": my_party[best_i],
                "best_mine_display": refdata.species_display(my_party[best_i]["speciesSlug"], my_party[best_i].get("nickname")),
                "reasoning_lines": lines,
                "score": pair_score["score"],
            })

        chosen_entries = [my_party[i] for i in combo]
        chosen_display = [refdata.species_display(e["speciesSlug"], e.get("nickname")) for e in chosen_entries]

        results.append({
            "rank": rank,
            "chosen": chosen_entries,
            "chosen_display": chosen_display,
            "total_score": total,
            "score_100": score_to_100(total, len(valid_opp_indices)),
            "lead": lead_entry,
            "lead_display": lead_display,
            "lead_reasoning": lead_reasoning,
            "lead_counts": lead_counts,
            "synergy_adjustment": synergy_adjustment,
            "synergy_notes": synergy_notes,
            "cohesion_details": cohesion_details,
            "per_opponent": per_opponent,
        })

    return {"results": results, "warnings": warnings}
