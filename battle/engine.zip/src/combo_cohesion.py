"""선출 3마리의 교체 연결, 공통 약점, 역할 균형을 평가한다.

턴 단위 시뮬레이션은 하지 않는다. 상대 로스터에 공개된 기술과 타입을 기준으로
'선봉이 불리할 때 받아줄 후보가 있는가'를 선출 단계에서 보조적으로 판단한다.
"""
from __future__ import annotations

from collections import Counter
import type_chart

ATTACK_TYPES = [
    "Normal", "Fire", "Water", "Electric", "Grass", "Ice", "Fighting", "Poison",
    "Ground", "Flying", "Psychic", "Bug", "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy",
]


def _display(entry, species):
    return entry.get("nickname") or (species or {}).get("nameKo") or entry.get("speciesSlug", "?")


def _has_batchim(text: str) -> bool:
    if not text:
        return False
    ch = text[-1]
    return "가" <= ch <= "힣" and (ord(ch) - ord("가")) % 28 != 0


def _particle(text: str, with_batchim: str, without_batchim: str) -> str:
    return text + (with_batchim if _has_batchim(text) else without_batchim)


def _defensive_mult(species, attack_type: str) -> float:
    if not species:
        return 1.0
    return type_chart.multiplier(attack_type, species.get("types", []))


def _offensive_role(entry: dict, refdata) -> str:
    lookup = {}
    for move in refdata.moves_by_id.values():
        en = (move.get("nameEn") or "").replace("’", "'").replace("‘", "'").strip().lower()
        ko = (move.get("nameKo") or "").strip().lower()
        if en:
            lookup[en] = move
        if ko:
            lookup[ko] = move
    physical = special = 0
    for name in entry.get("moves", []):
        key = (name or "").replace("’", "'").replace("‘", "'").strip().lower()
        move = lookup.get(key)
        if not move:
            continue
        if move.get("category") == "물리" and (move.get("power") or 0) > 0:
            physical += 1
        elif move.get("category") == "특수" and (move.get("power") or 0) > 0:
            special += 1
    if physical and special:
        return "mixed"
    if physical:
        return "physical"
    if special:
        return "special"
    return "support"


def _relevant_attack_types(opponent_party, resolve_move_types):
    types = []
    for opp in opponent_party:
        types.extend(resolve_move_types(opp.get("moves", [])))
    return set(types)


def evaluate_combo(combo, party, species_list, opponent_party, matrix, valid_opp_indices,
                   resolve_move_types, refdata) -> tuple[float, list[str], dict]:
    """조합 점수 보정과 사용자 설명을 반환한다."""
    adjustment = 0.0
    notes: list[str] = []
    details = {"switch_links": [], "shared_weaknesses": [], "roles": []}

    relevant_types = _relevant_attack_types(opponent_party, resolve_move_types)
    # 기술 정보가 없을 때는 전체 타입 기준으로 구조적 공통 약점만 약하게 본다.
    scan_types = relevant_types or set(ATTACK_TYPES)

    shared = []
    for attack_type in scan_types:
        weak = [i for i in combo if _defensive_mult(species_list[i], attack_type) >= 2.0]
        resistant = [i for i in combo if _defensive_mult(species_list[i], attack_type) <= 0.5]
        if len(weak) == len(combo):
            adjustment -= 0.8 if attack_type in relevant_types else 0.45
            shared.append((attack_type, len(weak), resistant))
        elif len(weak) >= 2 and not resistant:
            adjustment -= 0.35 if attack_type in relevant_types else 0.18
            shared.append((attack_type, len(weak), resistant))
        elif weak and resistant:
            adjustment += 0.08

    if shared:
        names = ", ".join(t for t, _, _ in shared[:3])
        notes.append(f"공통 약점 주의: {names}")
        details["shared_weaknesses"] = [t for t, _, _ in shared]

    # 상대별로 가장 불리한 선출원을 다른 포켓몬이 실제 피해/타입 양쪽에서 받아줄 수 있는지 평가.
    switch_links = Counter()
    uncovered = 0
    for j in valid_opp_indices:
        opp_types = set(resolve_move_types(opponent_party[j].get("moves", [])))
        if not opp_types:
            continue
        for source in combo:
            src_pair = matrix.get((source, j))
            if not src_pair or src_pair.get("estimated_taken_pct", 0) < 55:
                continue
            candidates = []
            for target in combo:
                if target == source:
                    continue
                tgt_pair = matrix.get((target, j))
                if not tgt_pair:
                    continue
                resists = any(_defensive_mult(species_list[target], t) <= 0.5 for t in opp_types)
                damage_drop = src_pair.get("estimated_taken_pct", 0) - tgt_pair.get("estimated_taken_pct", 0)
                if resists and damage_drop >= 15:
                    candidates.append((damage_drop, target))
            if candidates:
                _, best_target = max(candidates)
                switch_links[(source, best_target)] += 1
            else:
                uncovered += 1

    if switch_links:
        best_links = switch_links.most_common(2)
        for (source, target), count in best_links:
            sname = _display(party[source], species_list[source])
            tname = _display(party[target], species_list[target])
            notes.append(f"교체 연결: {_particle(sname, '이', '가')} 불리할 때 {_particle(tname, '이', '가')} 받아줄 후보")
            details["switch_links"].append({"from": source, "to": target, "count": count})
            adjustment += min(0.32, 0.10 + count * 0.04)
    shortage_threshold = max(5, len(valid_opp_indices))
    if uncovered >= shortage_threshold:
        adjustment -= min(0.6, uncovered * 0.06)
        notes.append("일부 불리한 상황에서는 안정적인 교체 후보가 부족함")

    # 상대 포켓몬마다 최소 한 마리가 확실한 대응 카드인지 확인.
    uncovered_opponents = 0
    for j in valid_opp_indices:
        best = max((matrix[(i, j)] for i in combo if (i, j) in matrix), key=lambda x: x["score"], default=None)
        if not best:
            continue
        if best["score"] < -0.15 or (best.get("estimated_taken_pct", 0) >= 90 and best.get("damage_max_pct", 0) < 70):
            uncovered_opponents += 1
    if uncovered_opponents:
        adjustment -= min(0.75, uncovered_opponents * 0.22)
        notes.append(f"확실한 대응 카드가 부족한 상대: {uncovered_opponents}마리")
    else:
        adjustment += 0.22
        notes.append("상대 전원에게 최소 한 명의 대응 카드 확보")

    roles = [_offensive_role(party[i], refdata) for i in combo]
    details["roles"] = roles
    counts = Counter(roles)
    if counts["physical"] == len(combo) or counts["special"] == len(combo):
        adjustment -= 0.35
        notes.append("공격 역할이 한쪽으로 치우침")
    elif "physical" in roles and "special" in roles:
        adjustment += 0.20
        notes.append("물리·특수 공격 역할이 균형적")
    if counts["support"] >= 2:
        adjustment -= 0.20
        notes.append("보조 역할이 겹쳐 마무리 화력이 부족할 수 있음")

    return adjustment, notes, details
