"""
포켓몬 챔피언스 실수치 계산기
------------------------------
챔피언스는 본가와 달리:
  - 개체값(IV) 없음 (전면 폐지)
  - 노력치 대신 "능력 포인트": 스탯당 최대 32, 총합 최대 66, 1포인트 = 실수치 1 직접 상승
  - 성격은 그대로 존재 (한 스탯 1.1배, 한 스탯 0.9배)
  - 랭크 배틀 기준 레벨 50
"""

from dataclasses import dataclass, field

MAX_POINTS_PER_STAT = 32
MAX_TOTAL_POINTS = 66

STAT_KEYS = ["hp", "atk", "def", "spa", "spd", "spe"]

# 성격표: (상승 스탯, 하락 스탯). 같으면 무보정.
NATURES = {
    "Hardy":   (None, None),
    "Lonely":  ("atk", "def"),
    "Brave":   ("atk", "spe"),
    "Adamant": ("atk", "spa"),
    "Naughty": ("atk", "spd"),
    "Bold":    ("def", "atk"),
    "Docile":  (None, None),
    "Relaxed": ("def", "spe"),
    "Impish":  ("def", "spa"),
    "Lax":     ("def", "spd"),
    "Timid":   ("spe", "atk"),
    "Hasty":   ("spe", "def"),
    "Serious": (None, None),
    "Jolly":   ("spe", "spa"),
    "Naive":   ("spe", "spd"),
    "Modest":  ("spa", "atk"),
    "Mild":    ("spa", "def"),
    "Quiet":   ("spa", "spe"),
    "Bashful": (None, None),
    "Rash":    ("spa", "spd"),
    "Calm":    ("spd", "atk"),
    "Gentle":  ("spd", "def"),
    "Sassy":   ("spd", "spe"),
    "Careful": ("spd", "spa"),
    "Quirky":  (None, None),
}


class ValidationError(Exception):
    pass


@dataclass
class BaseStats:
    hp: int
    atk: int
    def_: int
    spa: int
    spd: int
    spe: int

    @classmethod
    def from_dict(cls, d: dict) -> "BaseStats":
        return cls(hp=d["hp"], atk=d["atk"], def_=d["def"], spa=d["spa"], spd=d["spd"], spe=d["spe"])


def validate_ability_points(points: dict):
    """능력 포인트 배분이 규칙(스탯당 32, 총합 66)을 지키는지 검증."""
    for key in STAT_KEYS:
        if key not in points:
            raise ValidationError(f"'{key}' 스탯의 능력 포인트가 누락되었습니다.")
        v = points[key]
        if not (0 <= v <= MAX_POINTS_PER_STAT):
            raise ValidationError(f"'{key}' 능력 포인트는 0~{MAX_POINTS_PER_STAT} 범위여야 합니다. (입력값: {v})")
    total = sum(points[k] for k in STAT_KEYS)
    if total > MAX_TOTAL_POINTS:
        raise ValidationError(f"능력 포인트 총합은 최대 {MAX_TOTAL_POINTS}인데 {total}이 배분되었습니다.")


def calc_stat(base: int, points: int, level: int, stat_key: str, nature: str) -> int:
    """스탯 하나의 실수치 계산."""
    if stat_key == "hp":
        return int((base * 2 + points) * level / 100) + level + 10

    value = int((base * 2 + points) * level / 100) + 5

    boost, cut = NATURES.get(nature, (None, None))
    if stat_key == boost:
        value = int(value * 1.1)
    elif stat_key == cut:
        value = int(value * 0.9)
    return value


def calc_all_stats(base_stats: BaseStats, ability_points: dict, level: int, nature: str) -> dict:
    """6개 스탯 전부 계산해서 dict로 반환."""
    validate_ability_points(ability_points)
    if nature not in NATURES:
        raise ValidationError(f"알 수 없는 성격: {nature}")

    base_map = {
        "hp": base_stats.hp,
        "atk": base_stats.atk,
        "def": base_stats.def_,
        "spa": base_stats.spa,
        "spd": base_stats.spd,
        "spe": base_stats.spe,
    }

    return {
        key: calc_stat(base_map[key], ability_points[key], level, key, nature)
        for key in STAT_KEYS
    }


if __name__ == "__main__":
    # 간단한 동작 확인: 한카리아스, 스피드-공격 극단 배분, Jolly 성격
    garchomp_base = BaseStats(hp=108, atk=130, def_=95, spa=80, spd=85, spe=102)
    points = {"hp": 4, "atk": 32, "def": 0, "spa": 0, "spd": 0, "spe": 30}
    stats = calc_all_stats(garchomp_base, points, level=50, nature="Jolly")
    print("한카리아스 (능력포인트 HP4/ATK32/SPE30, Jolly, Lv50) 실수치:")
    for k, v in stats.items():
        print(f"  {k}: {v}")
