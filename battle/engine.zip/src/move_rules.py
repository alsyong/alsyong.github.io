"""챔피언스 기술의 특수 계산 규칙 로더."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

RULE_PATH = Path(__file__).resolve().parent.parent / "data" / "battle_rules" / "moves.json"

def normalize_move_name(name: str) -> str:
    return (name or "").replace("’", "'").replace("‘", "'").strip().lower()


@lru_cache(maxsize=1)
def _rules() -> dict:
    with RULE_PATH.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return {normalize_move_name(str(k)): v for k, v in raw.items()}


def move_rule(name: str) -> dict:
    return _rules().get(normalize_move_name(name), {})
