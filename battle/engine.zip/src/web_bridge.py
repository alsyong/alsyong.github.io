"""
웹 버전 연결부: 브라우저(Pyodide)에서 기존 판단 엔진을 그대로 호출하기 위한 얇은 래퍼.
- 계산 로직(matchup_engine 등)은 원본을 수정하지 않고 그대로 사용한다.
- 네트워크 조회는 하지 않고, 저장된 통계 캐시만 사용한다.
- 승패 기록은 저장하지 않는다(방문자별 기록 없음).
"""
import json
import os

import pikalytics_client
import battle_log
import matchup_engine
from reference_data import ReferenceData, all_nature_pairs
from stat_calc import BaseStats, calc_all_stats, validate_ability_points, ValidationError

# 웹에서는 외부 사이트 조회를 하지 않고 캐시만 쓴다.
_orig_fetch = pikalytics_client.fetch_best_set


def _cache_only_fetch(species_slug, fmt=pikalytics_client.DEFAULT_FORMAT, use_cache=True, allow_network=True):
    return _orig_fetch(species_slug, fmt, use_cache=True, allow_network=False)


pikalytics_client.fetch_best_set = _cache_only_fetch

# 방문자의 승패 기록은 남기지 않는다.
if hasattr(battle_log, "record_result"):
    battle_log.record_result = lambda *a, **k: None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REF = ReferenceData()
REF.load()


def _pairs(pairs):
    return [{"label": d, "value": v} for d, v in pairs]


def catalog():
    """화면 자동완성용 목록 (포켓몬, 도구, 성격)."""
    species = [
        {"slug": p["slug"], "label": REF.species_display(p["slug"]), "nameKo": p.get("nameKo") or "",
         "nameEn": p.get("nameEn") or p.get("name") or p["slug"]}
        for p in REF.pokemon
    ]
    items = _pairs(REF.search_items("", limit=100000))
    natures = _pairs(all_nature_pairs())
    from type_chart import TYPE_NAMES_KO
    move_labels = {}
    for m in REF.moves_by_id.values():
        en = m.get("nameEn") or ""
        if not en:
            continue
        name = m.get("nameKo") or en
        t = TYPE_NAMES_KO.get(m.get("type", ""), m.get("type", ""))
        move_labels[en] = f"({t}) {name}" if t else name
    ability_labels = {a.get("nameEn", ""): (a.get("nameKo") or a.get("nameEn", "")) for a in REF.abilities_by_id.values()}
    example_party = json.load(open(os.path.join(ROOT, "parties", "example_regmb.json"), encoding="utf-8"))["party"]
    example_opp = json.load(open(os.path.join(ROOT, "opponent_presets", "example.json"), encoding="utf-8"))["opponents"]
    return json.dumps({"species": species, "items": items, "natures": natures,
                       "moveLabels": move_labels, "abilityLabels": ability_labels,
                       "exampleParty": example_party, "exampleOpponents": example_opp}, ensure_ascii=False)


def species_options(slug):
    """선택한 포켓몬이 가질 수 있는 특성과 배울 수 있는 기술."""
    sp = REF.get_species(slug)
    if not sp:
        return json.dumps({"ok": False})
    abilities = _pairs(REF.get_abilities_for_species(slug))
    moves = _pairs(REF.get_learnable_moves_for_species(slug))
    return json.dumps({"ok": True, "abilities": abilities, "moves": moves,
                       "baseStats": sp.get("baseStats")}, ensure_ascii=False)


def calc_stats(slug, ability_points_json, nature):
    sp = REF.get_species(slug)
    if not sp:
        return json.dumps({"ok": False})
    ap = json.loads(ability_points_json)
    error = None
    try:
        validate_ability_points(ap)
    except ValidationError as e:
        error = str(e)
    except Exception as e:  # 검증 함수 시그니처가 다를 경우 대비
        error = None
    stats = calc_all_stats(BaseStats.from_dict(sp["baseStats"]), ap, 50, nature or "Hardy")
    stats = stats if isinstance(stats, dict) else getattr(stats, "__dict__", {})
    return json.dumps({"ok": True, "stats": stats, "error": error}, ensure_ascii=False)


def _opponent_entry(o):
    slug = o.get("speciesSlug")
    sp = REF.get_species(slug)
    item = o.get("item") or ""
    ability = o.get("ability") or ""
    moves = [m for m in (o.get("moves") or []) if m]
    item_blank, ability_blank, moves_blank = not item, not ability, not moves
    item, ability, moves, notes = pikalytics_client.fill_blanks(slug, item, ability, moves)
    return {
        "speciesSlug": slug,
        "nickname": sp["nameKo"] if sp else slug,
        "item": item,
        "ability": ability,
        "moves": moves,
        "itemAutoFilled": bool(item_blank and item),
        "abilityAutoFilled": bool(ability_blank and ability),
        "movesAutoFilled": bool(moves_blank and moves),
    }, notes


def recommend(my_party_json, opponents_json):
    my_party = json.loads(my_party_json)
    opponents = json.loads(opponents_json)
    opp_entries, fill_notes = [], []
    for o in opponents:
        if not o.get("speciesSlug"):
            continue
        entry, notes = _opponent_entry(o)
        opp_entries.append(entry)
        fill_notes.append({"slug": entry["speciesSlug"], "notes": notes})

    result = matchup_engine.rank_combos(my_party, opp_entries, REF, pick_count=3, top_n=3)

    out = []
    for r in result["results"]:
        out.append({
            "rank": r.get("rank"),
            "chosen": [c.get("speciesSlug") for c in r.get("chosen", [])],
            "chosen_display": r.get("chosen_display", []),
            "score_100": r.get("score_100"),
            "lead": (r.get("lead") or {}).get("speciesSlug") if r.get("lead") else None,
            "lead_display": r.get("lead_display"),
            "lead_reasoning": r.get("lead_reasoning"),
            "per_opponent": [
                {
                    "opponent": (row.get("opponent") or {}).get("speciesSlug"),
                    "opponent_display": row.get("opponent_display"),
                    "reasoning_lines": row.get("reasoning_lines", []),
                }
                for row in r.get("per_opponent", [])
            ],
        })
    return json.dumps({"results": out, "warnings": result.get("warnings", []),
                       "fill_notes": fill_notes,
                       "opponents": [{"slug": e["speciesSlug"], "item": e["item"], "ability": e["ability"],
                                      "moves": e["moves"]} for e in opp_entries]},
                      ensure_ascii=False, default=str)
