"""
참고 데이터(도감/특성/기술/도구/성격) 로딩 및 검색 헬퍼
GUI(party_editor.pyw, battle_helper.pyw)와 CLI(party_manager.py) 양쪽에서 공용으로 사용.

화면 표시는 기본적으로 한글만 보여준다 (도감에 한글 이름이 없는 경우에만 영문으로 대체).
저장/계산에는 영문 값이 필요하므로, 검색 함수들은 (표시용 문자열, 실제 영문 값) 쌍을 반환한다.
"""

import json
import os

from type_chart import TYPE_NAMES_KO

try:
    from stat_calc import NATURES as _STAT_NATURES
except ImportError:  # stat_calc가 아직 없거나 순환 참조 상황 대비
    _STAT_NATURES = {}

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT_DIR, "data")
PARTIES_DIR = os.path.join(ROOT_DIR, "parties")
OPPONENT_PRESETS_DIR = os.path.join(ROOT_DIR, "opponent_presets")

NATURE_NAMES_KO = {
    "Hardy": "무의지", "Lonely": "외로움", "Brave": "용감", "Adamant": "고집",
    "Naughty": "짓궂음", "Bold": "대담", "Docile": "온순", "Relaxed": "여유",
    "Impish": "장난꾸러기", "Lax": "천진난만", "Timid": "겁쟁이", "Hasty": "성급",
    "Serious": "성실", "Jolly": "명랑", "Naive": "순진", "Modest": "얌전",
    "Mild": "차분", "Quiet": "냉정", "Bashful": "부끄럼", "Rash": "덜렁",
    "Calm": "차분한", "Gentle": "온화", "Sassy": "건방", "Careful": "신중", "Quirky": "변덕",
}

_STAT_LABEL_KO = {"hp": "HP", "atk": "공격", "def": "방어", "spa": "특공", "spd": "특방", "spe": "스피드"}


def _first_present(d: dict, keys, default=""):
    """dict에서 여러 후보 키 이름 중 실제로 값이 있는 첫 번째를 반환. (원본 데이터의 필드명이
    문서마다 조금씩 다를 수 있어서 방어적으로 여러 이름을 시도한다.)"""
    for k in keys:
        v = d.get(k)
        if v:
            return v
    return default


def nature_display(name_en: str) -> str:
    """'Adamant' -> '고집 (공격↑, 특공↓)' 같은 형태로 성격 표시 문자열을 만든다."""
    ko = NATURE_NAMES_KO.get(name_en, name_en)
    boost, cut = _STAT_NATURES.get(name_en, (None, None))
    if not boost:
        return f"{ko} (변화없음)"
    return f"{ko} ({_STAT_LABEL_KO.get(boost, boost)}↑, {_STAT_LABEL_KO.get(cut, cut)}↓)"


def all_nature_pairs():
    """[(표시문자열, 영문 성격명), ...] 25종 전체."""
    return [(nature_display(en), en) for en in NATURE_NAMES_KO.keys()]


class ReferenceData:
    def __init__(self):
        self.pokemon = []          # champions_pokemon.json 원본 리스트
        self.abilities_by_id = {}  # "24" -> {"nameEn":..., "nameKo":...}
        self.moves_by_id = {}      # "337" -> {"nameEn":..., "nameKo":..., "type":...}
        self.items = []            # items.json 원본 (구조가 완전히 확정되진 않아 여러 필드명 시도)
        self.natures = list(NATURE_NAMES_KO.keys())

        self._species_by_slug = {}

    def loaded(self) -> bool:
        return bool(self.pokemon) and bool(self.moves_by_id)

    def load(self):
        self.pokemon = self._load_json("champions_pokemon.json", default=[])
        abilities_list = self._load_json("abilities.json", default=[])
        moves_list = self._load_json("moves.json", default=[])
        self.items = self._load_json("items.json", default=[])

        self.abilities_by_id = {a["id"]: a for a in abilities_list}
        self.moves_by_id = {m["id"]: m for m in moves_list}
        self._species_by_slug = {p["slug"]: p for p in self.pokemon}

    def _load_json(self, filename, default):
        path = os.path.join(DATA_DIR, filename)
        if not os.path.exists(path):
            return default
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    # ---------- 표시 문자열 만들기 ----------

    @staticmethod
    def _display(ko, en):
        """한글이 있으면 한글만, 없으면 영문으로 대체."""
        ko = (ko or "").strip()
        en = (en or "").strip()
        return ko or en

    # ---------- 포켓몬 종 ----------

    def search_species(self, query: str, limit: int = 30):
        """[(표시용 한글 이름, slug), ...] 목록. query가 비어있으면 처음 limit개."""
        query = query.strip().lower()
        results = []
        for p in self.pokemon:
            if not p.get("allowedInChampions", True):
                continue
            if not query or query in p["nameKo"].lower() or query in p["nameEn"].lower() or query in p["slug"].lower():
                results.append((self._display(p.get("nameKo"), p.get("nameEn")), p["slug"]))
                if len(results) >= limit:
                    break
        return results

    def get_species(self, slug: str):
        return self._species_by_slug.get(slug)

    def species_display(self, slug: str, fallback: str = None) -> str:
        """slug로 도감을 찾아 한글 표시 이름을 만든다. 도감에 없으면 fallback(예: 저장된 nickname) 또는 slug 자체를 반환."""
        species = self.get_species(slug)
        if species:
            return self._display(species.get("nameKo"), species.get("nameEn")) or slug
        return fallback or slug

    # ---------- 특성 ----------

    def get_abilities_for_species(self, slug: str):
        """[(표시용 한글 이름, 영문 특성명), ...] 이 포켓몬이 가질 수 있는 특성 목록."""
        species = self.get_species(slug)
        if not species:
            return []
        ids = species.get("abilities", [])
        pairs = [self.abilities_by_id[i] for i in ids if i in self.abilities_by_id]
        if not pairs:
            pairs = list(self.abilities_by_id.values())
        result = [(self._display(a.get("nameKo"), a.get("nameEn")), a.get("nameEn", "")) for a in pairs]
        return sorted(result, key=lambda x: x[0])

    # ---------- 기술 ----------

    def get_learnable_moves_for_species(self, slug: str):
        """[(표시용 '(타입) 한글이름', 영문 기술명), ...] 이 포켓몬이 배울 수 있는 기술, 가나다순 정렬."""
        species = self.get_species(slug)
        if not species:
            return []
        ids = species.get("learnableMoveIds", [])
        pairs = [self.moves_by_id[i] for i in ids if i in self.moves_by_id]
        result = []
        for m in pairs:
            name = self._display(m.get("nameKo"), m.get("nameEn"))
            type_ko = TYPE_NAMES_KO.get(m.get("type", ""), m.get("type", ""))
            display = f"({type_ko}) {name}" if type_ko else name
            result.append((display, m.get("nameEn", "")))
        return sorted(result, key=lambda x: x[0])

    # ---------- 도구 ----------

    def search_items(self, query: str, limit: int = 30):
        """[(표시용 한글 이름, 영문 도구명), ...]. 원본 items.json의 필드명이 확실하지 않아
        여러 후보 키를 시도해서 최대한 한글을 찾아낸다."""
        query = query.strip().lower()
        results = []
        for item in self.items:
            name_en = _first_present(item, ["nameEn", "name_en", "enName", "name"])
            name_ko = _first_present(item, ["nameKo", "name_ko", "koName", "korean", "ko"])
            display = self._display(name_ko, name_en)
            if not query or query in name_en.lower() or query in name_ko.lower() or query in display.lower():
                results.append((display, name_en))
                if len(results) >= limit:
                    break
        return results

    # ---------- 저장된 값 <-> 표시 문자열 변환 (콤보박스 등 비검색형 위젯용) ----------

    @staticmethod
    def display_for_english(pairs, english_value: str):
        """[(표시, 영문), ...] 목록에서 영문 값이 일치하는 표시 문자열을 찾는다. 못 찾으면 영문 값 그대로."""
        english_value = (english_value or "").strip()
        for display, value in pairs:
            if value == english_value:
                return display
        return english_value

    @staticmethod
    def english_for_display(pairs, display_value: str):
        """[(표시, 영문), ...] 목록에서 표시 문자열이 일치하는 영문 값을 찾는다. 못 찾으면 입력값 그대로
        (사용자가 목록에 없는 걸 직접 타이핑한 경우 대비)."""
        display_value = (display_value or "").strip()
        for display, value in pairs:
            if display == display_value:
                return value
        return display_value

    # ---------- 파티 저장/조회 ----------

    def list_saved_parties(self):
        if not os.path.isdir(PARTIES_DIR):
            return []
        return sorted(f[:-5] for f in os.listdir(PARTIES_DIR) if f.endswith(".json"))

    def load_party_file(self, name: str):
        path = os.path.join(PARTIES_DIR, f"{name}.json")
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_party_file(self, name: str, party_data: dict):
        os.makedirs(PARTIES_DIR, exist_ok=True)
        path = os.path.join(PARTIES_DIR, f"{name}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(party_data, f, ensure_ascii=False, indent=2)
        return path

    def delete_party_file(self, name: str) -> bool:
        path = os.path.join(PARTIES_DIR, f"{name}.json")
        if not os.path.exists(path):
            return False
        os.remove(path)
        return True

    # ---------- 상대팀 프리셋 ----------

    def list_opponent_presets(self):
        if not os.path.isdir(OPPONENT_PRESETS_DIR):
            return []
        return sorted(f[:-5] for f in os.listdir(OPPONENT_PRESETS_DIR) if f.endswith(".json"))

    def load_opponent_preset(self, name: str):
        path = os.path.join(OPPONENT_PRESETS_DIR, f"{name}.json")
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_opponent_preset(self, name: str, opponents: list):
        os.makedirs(OPPONENT_PRESETS_DIR, exist_ok=True)
        path = os.path.join(OPPONENT_PRESETS_DIR, f"{name}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"opponents": opponents}, f, ensure_ascii=False, indent=2)
        return path

    def delete_opponent_preset(self, name: str) -> bool:
        path = os.path.join(OPPONENT_PRESETS_DIR, f"{name}.json")
        if not os.path.exists(path):
            return False
        os.remove(path)
        return True
