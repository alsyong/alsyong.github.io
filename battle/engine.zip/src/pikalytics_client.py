"""
Pikalytics에서 포켓몬별 실전 사용률 데이터(도구/특성/기술 Top pick)를 가져오는 모듈.
사용자가 상대 포켓몬의 도구/특성/기술을 비워두면 여기서 자동으로 채워줍니다.

- 한 번 가져온 데이터는 data/pikalytics_cache/ 에 캐싱해서, 같은 포켓몬을 또 조회할 때
  네트워크 요청 없이 즉시 응답합니다 (로딩 지연 방지).
- Pikalytics는 로그인 없이 공개적으로 이용 가능하고, AI/자동화 조회를 명시적으로 허용하는
  사이트입니다 (llms.txt 제공).
"""

import html
import json
import os
import re
import urllib.request

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(ROOT_DIR, "data", "pikalytics_cache")

# 현재 랭크 배틀에 쓰이는 레귤레이션. 시즌이 바뀌면 이 값을 갱신해야 합니다.
# (예: pikalytics.com에서 최신 챔피언스 포맷 슬러그를 확인)
DEFAULT_FORMAT = "gen9championsvgc2026regmb"

_HEADERS = {"User-Agent": "Mozilla/5.0 (personal-use pokemon-champions-tool)"}


def slug_to_pikalytics_name(slug: str) -> str:
    """yodams 스타일 slug(예: charizard-mega-y)를 Pikalytics URL 표기(Charizard-Mega-Y)로 변환."""
    parts = slug.split("-")
    return "-".join(p.capitalize() for p in parts if p)


def _strip_html(raw_html: str) -> str:
    """아주 단순한 HTML 태그 제거기. 표/스크립트를 걷어내고 텍스트만 남긴다."""
    text = re.sub(r"<script.*?</script>", " ", raw_html, flags=re.S | re.I)
    text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = html.unescape(text)
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    return "\n".join(lines)


def _extract_section(text: str, header: str, next_headers) -> str:
    """'## Best Moves for X' 같은 헤더 다음부터, 다음 헤더가 나오기 전까지의 블록을 추출."""
    idx = text.find(header)
    if idx == -1:
        return ""
    rest = text[idx + len(header):]
    end = len(rest)
    for nh in next_headers:
        pos = rest.find(nh)
        if pos != -1:
            end = min(end, pos)
    return rest[:end]


def _parse_ranked_list(block: str, max_items: int):
    """
    Pikalytics 포켓몬 페이지의 'Name \n type \n XX.X%' 반복 패턴에서 이름만 순서대로 추출.
    타입 이름, 퍼센트 줄은 건너뛰고 '이름처럼 생긴 줄'만 골라낸다.
    """
    return [name for name, _ in _parse_ranked_list_with_pct(block, max_items)]


def _parse_ranked_list_with_pct(block: str, max_items: int):
    """_parse_ranked_list와 같은 패턴이지만 (이름, 퍼센트) 쌍으로 반환한다.
    이름 줄 바로 다음에 나오는 첫 퍼센트 줄을 그 이름의 사용률로 간주한다."""
    lines = [ln for ln in block.splitlines() if ln.strip()]
    percent_re = re.compile(r"^(\d+(?:\.\d+)?)%$")
    results = []
    pending_name = None
    for ln in lines:
        m = percent_re.match(ln)
        if m:
            if pending_name is not None:
                results.append((pending_name, float(m.group(1))))
                pending_name = None
                if len(results) >= max_items:
                    break
            continue
        if ln.islower():  # 타입 이름은 소문자로만 표기됨 (fire, water 등)
            continue
        pending_name = ln.strip()
    return results


_SPREAD_RE = re.compile(r"^(\d{1,3})\s*/\s*(\d{1,3})\s*/\s*(\d{1,3})\s*/\s*(\d{1,3})\s*/\s*(\d{1,3})\s*/\s*(\d{1,3})$")
_SPREAD_NUM_RE = re.compile(r"^(\d{1,3})/?$")
_PERCENT_RE = re.compile(r"^(\d+(?:\.\d+)?)%$")


def _parse_top_spread(block: str):
    """1위 노력치 배분과 그 채용률을 찾아 반환한다.
    반환: {"hp":2,"atk":32,"def":0,"spa":0,"spd":0,"spe":32,"percent":32.7} 또는 None.

    실제 pikalytics.com 페이지(2026-07-21 확인)는 '2 / 32 / 0 / 0 / 0 / 32' 한 줄이 아니라
    <br>마다 줄바꿈되어 스탯 6개가 "2/", "32/", "0/", "0/", "0/", "32"처럼 한 줄에 하나씩
    나온다. 예전 가정(한 줄 표기)도 혹시 모를 다른 레이아웃을 위해 그대로 남겨서 같이 검사한다.
    """
    lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
    i = 0
    while i < len(lines):
        m = _SPREAD_RE.match(lines[i])
        if m:
            nums = [int(x) for x in m.groups()]
            consumed = 1
        else:
            window = lines[i:i + 6]
            if len(window) == 6 and all(_SPREAD_NUM_RE.match(w) for w in window):
                nums = [int(_SPREAD_NUM_RE.match(w).group(1)) for w in window]
                consumed = 6
            else:
                nums = None
        if nums is not None and all(0 <= n <= 252 for n in nums) and sum(nums) <= 508:
            pct = None
            pct_idx = i + consumed
            if pct_idx < len(lines):
                pm = _PERCENT_RE.match(lines[pct_idx])
                if pm:
                    pct = float(pm.group(1))
            hp, atk, de, spa, spd, spe = nums
            return {"hp": hp, "atk": atk, "def": de, "spa": spa, "spd": spd, "spe": spe, "percent": pct}
        i += 1
    return None


def _parse_top_nature(block: str):
    """'Nature' 섹션에서 1위 성격 이름과 퍼센트를 찾는다. 형식이 다르면 None."""
    known_natures = {
        "Hardy", "Lonely", "Brave", "Adamant", "Naughty", "Bold", "Docile", "Relaxed",
        "Impish", "Lax", "Timid", "Hasty", "Serious", "Jolly", "Naive", "Modest",
        "Mild", "Quiet", "Bashful", "Rash", "Calm", "Gentle", "Sassy", "Careful", "Quirky",
    }
    lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
    percent_re = re.compile(r"^(\d+(?:\.\d+)?)%$")
    for idx, ln in enumerate(lines):
        if ln in known_natures:
            pct = None
            if idx + 1 < len(lines):
                pm = percent_re.match(lines[idx + 1])
                if pm:
                    pct = float(pm.group(1))
            return {"nature": ln, "percent": pct}
    return None


def _normalize_cached(data: dict) -> dict:
    """구형 캐시도 네트워크 재조회 없이 안전하게 재사용한다."""
    normalized = dict(data or {})
    normalized.setdefault("ability", None)
    normalized.setdefault("item", None)
    normalized.setdefault("moves", [])
    normalized.setdefault("moveUsage", {})
    normalized.setdefault("abilityUsage", {})
    normalized.setdefault("topNature", None)
    normalized.setdefault("topSpread", None)
    return normalized


def fetch_best_set(species_slug: str, fmt: str = DEFAULT_FORMAT, use_cache: bool = True, allow_network: bool = True) -> dict:
    """
    반환 형식:
    {
      "ability": "Rough Skin" 또는 None,
      "item": "Life Orb" 또는 None,
      "moves": ["Dragon Claw", "Rock Slide", "Earthquake", "Protect"] (최대 4개, 못 찾으면 []),
      "moveUsage": {"Dragon Claw": 89.4, ...} (파악되는 만큼, 최대 12개 정도),
      "abilityUsage": {"Rough Skin": 98.5, ...} (파악되는 만큼, 보통 1~3개),
      "topNature": {"nature": "Jolly", "percent": 60.5} 또는 None,
      "topSpread": {"hp":2,"atk":32,...,"percent":32.7} 또는 None,
      "source": "cache" | "network" | "unavailable",
    }
    2026-07-21: garchomp/charizard 실제 페이지 응답으로 topNature/topSpread 파싱을 검증하고
      두 가지 버그를 고쳤다 - (1) "Nature"/"EV Spreads" 두 헤더가 나란히 나온 뒤 EV 배분표가
      먼저, 성격 목록이 나중에 나오는데 예전 코드는 "Spreads"를 nature_block 종료 지점으로 써서
      성격 데이터가 나오기 전에 블록이 끊겼다. (2) 실제 페이지는 노력치 6개가 한 줄이 아니라
      한 줄에 하나씩 나오는데 파서가 한 줄 표기만 인식했다. 검증 중 abilityUsage가 신규 조회에서는
      전혀 계산되지 않던 것도 같이 발견해 moveUsage와 같은 방식으로 채워지도록 고쳤다. 기존
      캐시(data/pikalytics_cache/)는 이 문제들이 있던 시절에 저장된 것이므로, 최신 값이 필요하면
      해당 종 캐시 파일을 지우고 다시 조회해야 한다.
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    cache_path = os.path.join(CACHE_DIR, f"{species_slug}__{fmt}.json")

    if use_cache and os.path.exists(cache_path):
        with open(cache_path, "r", encoding="utf-8") as f:
            data = _normalize_cached(json.load(f))
        data["source"] = "cache"
        return data

    if not allow_network:
        return {
            "ability": None, "item": None, "moves": [], "moveUsage": {}, "abilityUsage": {},
            "topNature": None, "topSpread": None, "source": "unavailable",
        }

    pikalytics_name = slug_to_pikalytics_name(species_slug)
    url = f"https://www.pikalytics.com/pokedex/{fmt}/{pikalytics_name}"

    try:
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8", errors="ignore")
    except Exception:
        return {
            "ability": None, "item": None, "moves": [], "moveUsage": {}, "abilityUsage": {},
            "topNature": None, "topSpread": None, "source": "unavailable",
        }

    text = _strip_html(raw)

    moves_block = _extract_section(text, f"Best Moves for {pikalytics_name}", ["Best Teammates", "Best Items"])
    items_block = _extract_section(text, f"Best Items for {pikalytics_name}", ["Best Abilities", "Nature"])
    abilities_block = _extract_section(text, f"Best Abilities for {pikalytics_name}", ["Nature", "Type Matchups"])
    # 실제 페이지(2026-07-21 확인)는 "Nature"/"EV Spreads" 두 헤더가 나란히 나온 뒤, EV 배분
    # 표가 먼저 나오고 그 다음에야 성격별 채용률이 나온다 - 헤더 순서와 데이터 순서가 다르다.
    # "Spreads"를 nature_block의 종료 지점으로 쓰면 실제 성격 데이터가 나오기도 전에 잘려서
    # 항상 빈 블록이 됐다. 두 파서 모두 위치와 무관하게 자기 패턴만 찾으므로, 하나의 넓은
    # 블록을 같이 넘겨써도 안전하다.
    nature_spread_block = _extract_section(text, "Nature", ["Type Matchups", "Best Teammates", "Checks"])

    moves = _parse_ranked_list(moves_block, max_items=4)
    move_usage = dict(_parse_ranked_list_with_pct(moves_block, max_items=12))
    items = _parse_ranked_list(items_block, max_items=1)
    abilities = _parse_ranked_list(abilities_block, max_items=1)
    # moveUsage와 같은 방식으로 특성 채용률도 뽑아둔다. 예전에는 이 결과가 아예 계산되지
    # 않아서, matchup_engine.field_ability_note가 기대하는 abilityUsage가 신규 조회에서는
    # 항상 비어 있었다(캐시 갱신 중 발견 - data/pikalytics_cache/CACHE_SNAPSHOT.json 쪽은
    # 별도로 수기 작성된 값이라 이 문제가 가려져 있었다).
    ability_usage = dict(_parse_ranked_list_with_pct(abilities_block, max_items=12))
    top_nature = _parse_top_nature(nature_spread_block)
    top_spread = _parse_top_spread(nature_spread_block)

    result = {
        "ability": abilities[0] if abilities else None,
        "item": items[0] if items else None,
        "moves": moves,
        "moveUsage": move_usage,
        "abilityUsage": ability_usage,
        "topNature": top_nature,
        "topSpread": top_spread,
    }

    with open(cache_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    result["source"] = "network"
    return result


def fill_blanks(species_slug: str, item: str, ability: str, moves):
    """item/ability/moves 중 비어있는 항목을 Pikalytics 1위 데이터로 채운다.
    반환: (item, ability, moves, notes) - notes는 자동으로 채운 내역 설명 리스트."""
    notes = []
    if item and ability and moves:
        return item, ability, moves, notes

    fetched = fetch_best_set(species_slug)
    if fetched["source"] == "unavailable":
        notes.append("Pikalytics 조회 실패 - 빈 항목은 공란으로 둡니다")
        return item, ability, moves, notes

    if not item and fetched["item"]:
        item = fetched["item"]
        notes.append(f"도구={item}(자동)")
    if not ability and fetched["ability"]:
        ability = fetched["ability"]
        notes.append(f"특성={ability}(자동)")
    if not moves and fetched["moves"]:
        moves = fetched["moves"]
        notes.append(f"기술={', '.join(moves)}(자동)")

    return item, ability, moves, notes


if __name__ == "__main__":
    import sys
    slug = sys.argv[1] if len(sys.argv) > 1 else "garchomp"
    print(f"조회: {slug}")
    print(json.dumps(fetch_best_set(slug), ensure_ascii=False, indent=2))
