"""간이 배틀 평가 모델.

정확한 난수 데미지 계산기가 아니라 선출 추천용 상대 비교 모델이다.
기술 위력/분류/명중률, 실수치, 자속, 타입, 주요 특성·도구를 일관된 방식으로 반영한다.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import type_chart
import battle_rules
import move_rules
from stat_calc import BaseStats, calc_all_stats

STAT_KEYS = ["hp", "atk", "def", "spa", "spd", "spe"]



STATUS_ALIASES = {
    "burn": "burn", "burned": "burn", "화상": "burn",
    "paralysis": "paralysis", "paralyzed": "paralysis", "마비": "paralysis",
    "poison": "poison", "poisoned": "poison", "독": "poison",
    "bad_poison": "bad_poison", "badly poisoned": "bad_poison", "맹독": "bad_poison",
    "sleep": "sleep", "asleep": "sleep", "잠듦": "sleep",
    "freeze": "freeze", "frozen": "freeze", "얼음": "freeze",
}

def normalized_status(entry: dict) -> str:
    raw = entry.get("statusCondition", entry.get("status", ""))
    return STATUS_ALIASES.get(str(raw or "").strip().lower(), str(raw or "").strip().lower())

def has_major_status(entry: dict) -> bool:
    return normalized_status(entry) in {"burn", "paralysis", "poison", "bad_poison", "sleep", "freeze"}

def stat_stage(entry: dict, key: str) -> int:
    stages = entry.get("statStages") or entry.get("stages") or {}
    try:
        return max(-6, min(6, int(stages.get(key, 0))))
    except (TypeError, ValueError):
        return 0

def stage_multiplier(stage: int) -> float:
    return (2 + stage) / 2 if stage >= 0 else 2 / (2 - stage)

def staged_stat(stats: dict, entry: dict, key: str) -> float:
    return float(stats[key]) * stage_multiplier(stat_stage(entry, key))

def can_receive_status(status: str, move: dict, defender_entry: dict, defender_species: dict) -> bool:
    types = set(defender_species.get("types", []))
    ability = ability_key(defender_entry.get("ability", ""))
    if ability == "Good as Gold" and status_move_targets_defender(move):
        return False
    if move_rules.move_rule(move.get("nameEn", "")).get("powderMove") and "Grass" in types:
        return False
    if status == "burn":
        if "Fire" in types or ability in {"Water Bubble"}:
            return False
    elif status == "paralysis":
        if "Electric" in types or ability == "Limber":
            return False
    elif status in {"poison", "bad_poison"}:
        if types.intersection({"Poison", "Steel"}) or ability in {"Immunity"}:
            return False
    elif status == "sleep":
        if ability in {"Insomnia", "Vital Spirit", "Sweet Veil"}:
            return False
    return True

STATUS_MOVE_UTILITY = {
    "Protect": 30, "King's Shield": 34, "Detect": 30,
    "Recover": 32, "Roost": 32, "Slack Off": 32, "Soft-Boiled": 32,
    "Swords Dance": 28, "Nasty Plot": 28, "Dragon Dance": 30, "Calm Mind": 26,
    "Will-O-Wisp": 28, "Thunder Wave": 27, "Spore": 35, "Sleep Powder": 27,
    "Stealth Rock": 22, "Spikes": 18, "Toxic Spikes": 18, "Sticky Web": 24,
    "Tailwind": 32, "Trick Room": 32, "Encore": 25, "Taunt": 24,
    "Destiny Bond": 25, "Substitute": 23, "Leech Seed": 22,
}

@dataclass
class MoveEval:
    name: str
    category: str
    power: int
    accuracy: int
    type_mult: float
    stab: float
    raw_damage: float
    hp_fraction: float
    utility: float
    priority: int
    damage_min: float = 0.0
    damage_max: float = 0.0
    hp_fraction_min: float = 0.0
    hp_fraction_max: float = 0.0
    hit_chance: float = 1.0
    # 첫 타격 생존/피해 완화 적용 전의 이론상 범위
    base_damage_min: float = 0.0
    base_damage_max: float = 0.0
    base_hp_fraction_min: float = 0.0
    base_hp_fraction_max: float = 0.0
    opening_effect_kind: str = ""
    opening_effect_name: str = ""
    opening_effect_note: str = ""
    first_action_ko_blocked: bool = False
    survival_chance: float = 0.0
    min_hits: int = 1
    max_hits: int = 1
    operation_kind: str = ""
    operation_note: str = ""


def move_lookup(refdata):
    return {
        move_rules.normalize_move_name(m.get("nameEn") or ""): m
        for m in refdata.moves_by_id.values()
        if (m.get("nameEn") or "").strip()
    }


def item_key(item: str) -> str:
    return (item or "").strip().lower()


def ability_key(ability: str) -> str:
    return (ability or "").strip()


def combat_species(entry: dict, refdata):
    """정확한 메가스톤을 들고 있으면 해당 메가폼을 사용한다."""
    base = refdata.get_species(entry.get("speciesSlug", ""))
    if not base:
        return None
    item = item_key(entry.get("item", ""))
    slug = entry.get("speciesSlug", "")
    if not item or "ite" not in item or "mega" in slug:
        return base
    # 상대 정보의 빈칸을 Pikalytics 1위 항목으로 자동 보충한 경우에는
    # 실제 도구를 확인한 것이 아니다. 특히 X/Y 복수 메가폼 중 하나를
    # 자동값 하나로 확정하면 다른 폼을 누락하므로 기본 폼으로 남겨 두고
    # matchup_engine에서 가능한 모든 메가 시나리오를 비교한다.
    if entry.get("itemAutoFilled"):
        return base
    forms = [p for p in refdata.pokemon if p.get("slug", "").startswith(slug + "-mega")]
    if not forms:
        return base
    # X/Y처럼 복수 폼이면 도구명 끝 글자로 구분
    if len(forms) > 1:
        if item.endswith(" x") or item.endswith("ite x"):
            for f in forms:
                if f["slug"].endswith("-x"):
                    return f
        if item.endswith(" y") or item.endswith("ite y"):
            for f in forms:
                if f["slug"].endswith("-y"):
                    return f
        return base  # 불명확한 메가스톤은 함부로 폼을 확정하지 않음
    return forms[0]


def is_grounded(entry: dict, species: dict) -> bool:
    """선출 추천에 필요한 범위에서 포켓몬이 지면에 있는지 판정한다."""
    if "Flying" in set(species.get("types", [])):
        return False
    if ability_key(entry.get("ability", "")) == "Levitate":
        return False
    if item_key(entry.get("item", "")) == "air balloon":
        return False
    return True


def field_move_multiplier(move_type: str, attacker_entry: dict, attacker_species: dict,
                          defender_entry: dict) -> float:
    """등장 특성으로 즉시 만들어지는 필드의 간이 위력 보정.

    현재는 메가라이츄X의 일렉트릭메이커를 포함해, 양쪽 중 누구든
    Electric Surge를 가진 상황에서 지면의 공격자가 쓰는 전기 기술을
    1.3배로 반영한다. 필드 지속 턴 전체를 시뮬레이션하는 기능은 아니며
    첫 대면의 즉시 화력 비교용이다.
    """
    if move_type != "Electric":
        return 1.0
    abilities = {
        ability_key(attacker_entry.get("ability", "")),
        ability_key(defender_entry.get("ability", "")),
    }
    if "Electric Surge" not in abilities:
        return 1.0
    return 1.3 if is_grounded(attacker_entry, attacker_species) else 1.0


def actual_stats(entry: dict, species: dict) -> dict:
    points = entry.get("abilityPoints") or {k: 0 for k in STAT_KEYS}
    return calc_all_stats(
        BaseStats.from_dict(species["baseStats"]), points,
        entry.get("level", 50), entry.get("nature", "Hardy")
    )


def estimated_stats(species: dict, role: str = "balanced") -> dict:
    """상대의 미입력 능력치는 총 66포인트 범위 안에서 보수적으로 추정한다."""
    points = {k: 0 for k in STAT_KEYS}
    if role == "physical":
        points.update(atk=32, spe=32, hp=2)
    elif role == "special":
        points.update(spa=32, spe=32, hp=2)
    elif role == "physical_bulk":
        points.update({"hp": 32, "def": 32, "spd": 2})
    elif role == "special_bulk":
        points.update({"hp": 32, "spd": 32, "def": 2})
    else:
        points.update({"hp": 22, "def": 22, "spd": 22})
    return calc_all_stats(BaseStats.from_dict(species["baseStats"]), points, 50, "Hardy")


def effective_type_multiplier(move_type: str, defender_types, defender_ability: str) -> float:
    rule = battle_rules.ability_rule(defender_ability)
    if move_type in set(rule.get("incomingImmunities", [])):
        return 0.0

    mult = type_chart.multiplier(move_type, defender_types)
    mult *= float(rule.get("incomingTypeMultipliers", {}).get(move_type, 1.0))
    if mult > 1:
        mult *= float(rule.get("superEffectiveMultiplier", 1.0))

    # 불가사의부적은 '효과가 굉장한 공격기만 통과'라는 복잡한 판정이라 코드에 유지한다.
    if ability_key(defender_ability) == "Wonder Guard" and mult <= 1:
        return 0.0
    return mult


def offensive_ability_multiplier(ability: str, move_type: str) -> float:
    """공격 기술 위력에 직접 적용되는 데이터형 특성 보정."""
    rule = battle_rules.ability_rule(ability)
    return float(rule.get("outgoingTypeMultipliers", {}).get(move_type, 1.0))


def status_move_targets_defender(move: dict) -> bool:
    """황금몸 판정을 위한 간이 표적 분류.

    기술 데이터에 target 필드가 없어 영문 설명을 이용한다.
    자기 강화·회복·보호 및 필드 설치기는 상대 포켓몬을 직접 대상으로
    하지 않으므로 황금몸에 막히지 않는 것으로 처리한다.
    """
    name = move.get("nameEn", "")
    non_targeting = {
        "Protect", "Detect", "King's Shield", "Recover", "Roost",
        "Slack Off", "Soft-Boiled", "Swords Dance", "Nasty Plot",
        "Dragon Dance", "Calm Mind", "Stealth Rock", "Spikes",
        "Toxic Spikes", "Sticky Web", "Tailwind", "Trick Room",
        "Substitute",
    }
    if name in non_targeting:
        return False
    desc = (move.get("descriptionEn") or "").lower()
    self_or_field_markers = (
        "the user's", "the user’s", "user's", "user’s",
        "opponent's side", "opponent’s side", "the field", "weather",
    )
    if any(marker in desc for marker in self_or_field_markers):
        return False
    target_markers = (
        "the target", "target's", "target’s", "the foe", "opposing pokémon",
        "paralyzes the target", "burns the target", "puts the target",
    )
    return any(marker in desc for marker in target_markers) or name in {
        "Will-O-Wisp", "Thunder Wave", "Spore", "Sleep Powder",
        "Taunt", "Encore", "Leech Seed", "Destiny Bond",
    }


def offensive_item_multiplier(item: str, category: str, move_type: str = "", type_mult: float = 1.0) -> float:
    rule = battle_rules.item_rule(item)
    mult = float(rule.get("outgoingMultiplier", 1.0))
    mult *= float(rule.get("categoryMultipliers", {}).get(category, 1.0))
    mult *= float(rule.get("outgoingTypeMultipliers", {}).get(move_type, 1.0))
    if type_mult > 1:
        mult *= float(rule.get("superEffectiveMultiplier", 1.0))
    return mult


def defensive_item_multiplier(item: str, move_type: str, type_mult: float) -> float:
    rule = battle_rules.item_rule(item)
    mult = float(rule.get("incomingTypeMultipliers", {}).get(move_type, 1.0))
    if type_mult > 1:
        mult *= float(rule.get("incomingSuperEffectiveTypeMultipliers", {}).get(move_type, 1.0))
    return mult


def move_accuracy_multiplier(attacker_item: str, defender_item: str) -> float:
    atk_rule = battle_rules.item_rule(attacker_item)
    def_rule = battle_rules.item_rule(defender_item)
    return float(atk_rule.get("accuracyMultiplier", 1.0)) * float(def_rule.get("incomingAccuracyMultiplier", 1.0))


def _opening_effects(entry: dict, ignore_ability: bool = False) -> list[dict]:
    """현재 대면의 첫 타격에 적용 가능한 특성/도구 효과를 반환한다.

    선출 단계에서는 별도 상태가 없으면 특성과 도구가 아직 소모되지 않은 것으로 본다.
    전투 상태 입력을 사용할 때는 disguiseBroken, abilityEffectConsumed,
    itemConsumed 값을 통해 이미 소모된 효과를 끌 수 있다.
    """
    effects = []
    if not ignore_ability and not entry.get("abilityEffectConsumed", False):
        effect = battle_rules.ability_rule(entry.get("ability", "")).get("openingEffect")
        if effect:
            if effect.get("kind") != "disguise" or not entry.get("disguiseBroken", False):
                effects.append({**effect, "source": "ability"})
    if not entry.get("itemConsumed", False):
        effect = battle_rules.item_rule(entry.get("item", "")).get("openingEffect")
        if effect:
            effects.append({**effect, "source": "item"})
    return effects


def _hit_bounds(rule: dict) -> tuple[int, int]:
    hit_rule = rule.get("hitRule")
    if hit_rule == "two_hits":
        return 2, 2
    if hit_rule == "two_to_five":
        return 2, 5
    if hit_rule == "population_bomb":
        return 1, 10
    return 1, 1


def _simulate_opening_damage(per_hit_damage: float, hits: int, defender_entry: dict,
                             defender_stats: dict, effects: list[dict],
                             direct_damage: bool = False) -> tuple[float, set[str], bool]:
    """주어진 타격 수에서 첫 타격 효과를 적용한 실제 피해를 근사한다.

    연속기는 탈/멀티스케일/옹골참/기합의띠가 첫 타격에만 관여하고,
    이후 타격은 현재 HP 상태를 이어 받아 계산한다.
    """
    max_hp = max(1.0, float(defender_stats["hp"]))
    current_hp = max_hp * _hp_fraction(defender_entry, defender_stats)
    full_hp = current_hp >= max_hp * 0.999
    total = 0.0
    triggered: set[str] = set()
    guaranteed_block = False

    ability_effects = [e for e in effects if e.get("source") == "ability"]
    item_effects = [e for e in effects if e.get("source") == "item"]

    for hit_index in range(max(1, int(hits))):
        damage = max(0.0, float(per_hit_damage))
        # 무효화되어 실제 피해가 발생하지 않는 타격은 탈·멀티스케일·생존 효과를 소모하지 않는다.
        if damage <= 0:
            continue

        # 특성 효과가 도구보다 먼저 판정된다. 탈은 첫 타격의 피해 자체를 대체한다.
        disguise = next((e for e in ability_effects if e.get("kind") == "disguise"), None)
        if hit_index == 0 and disguise is not None:
            damage = max_hp * float(disguise.get("hpCostFraction", 0.125))
            triggered.add(disguise.get("labelKo", "탈"))
            if hits == 1 and current_hp > damage:
                guaranteed_block = True
        else:
            multiscale = next((e for e in ability_effects if e.get("kind") == "full_hp_first_hit_multiplier"), None)
            if hit_index == 0 and full_hp and multiscale is not None and not direct_damage:
                damage *= float(multiscale.get("multiplier", 1.0))
                triggered.add(multiscale.get("labelKo", "피해 완화 특성"))

            # 옹골참/기합의띠는 해당 타격 직전 HP가 가득 찼고 그 타격이 치명적일 때만 발동한다.
            endure_effects = [
                e for e in ability_effects + item_effects
                if e.get("kind") == "full_hp_endure"
            ]
            if current_hp >= max_hp * 0.999 and damage >= current_hp and endure_effects:
                chosen = endure_effects[0]
                damage = max(0.0, current_hp - 1.0)
                triggered.add(chosen.get("labelKo", "생존 효과"))
                if hits == 1:
                    guaranteed_block = True

        total += damage
        current_hp -= min(current_hp, damage)
        if current_hp <= 0:
            break

    return total, triggered, guaranteed_block


def _apply_opening_effects(*, base_min: float, base_max: float, per_hit_min: float,
                           per_hit_max: float, raw_on_hit: float, min_hits: int,
                           max_hits: int, expected_hits: float, defender_entry: dict,
                           defender_stats: dict, attacker_entry: dict,
                           direct_damage: bool = False) -> dict:
    """첫 타격 생존/완화 효과를 피해 범위와 기대 피해에 함께 반영한다."""
    ignore_ability = ability_key(attacker_entry.get("ability", "")) == "Mold Breaker"
    effects = _opening_effects(defender_entry, ignore_ability=ignore_ability)
    if not effects:
        return {
            "damage_min": base_min, "damage_max": base_max,
            "raw_on_hit": raw_on_hit, "kind": "", "name": "", "note": "",
            "first_action_ko_blocked": False, "survival_chance": 0.0,
        }

    low, low_triggered, low_blocked = _simulate_opening_damage(
        per_hit_min, min_hits, defender_entry, defender_stats, effects, direct_damage
    )
    high, high_triggered, high_blocked = _simulate_opening_damage(
        per_hit_max, max_hits, defender_entry, defender_stats, effects, direct_damage
    )
    triggered = low_triggered | high_triggered

    # 기대 타수는 정수가 아닐 수 있으므로 첫 타격 변화량을 기준으로 기대 피해를 보정한다.
    expected = raw_on_hit
    max_hp = max(1.0, float(defender_stats["hp"]))
    full_hp = _hp_fraction(defender_entry, defender_stats) >= 0.999
    kinds = []
    notes = []
    names = []

    for effect in effects:
        kind = effect.get("kind", "")
        label = effect.get("labelKo", "")
        if label in triggered:
            names.append(label)
            kinds.append(kind)
        if kind == "disguise" and label in triggered:
            first_normal = raw_on_hit / max(1.0, expected_hits)
            expected = max_hp * float(effect.get("hpCostFraction", 0.125)) + max(0.0, raw_on_hit - first_normal)
            if max_hits > 1:
                notes.append("탈이 첫 타격의 피해를 대신 받지만 연속 공격의 나머지 타격은 정상적으로 적용됨")
            else:
                notes.append("탈이 남아 있어 첫 공격의 피해가 최대 HP의 1/8로 대체됨")
        elif kind == "full_hp_first_hit_multiplier" and label in triggered:
            multiplier = float(effect.get("multiplier", 1.0))
            first_normal = raw_on_hit / max(1.0, expected_hits)
            expected -= first_normal * (1.0 - multiplier)
            if max_hits > 1:
                notes.append(f"풀 HP 기준 {label}은 연속 공격의 첫 타격만 {multiplier:g}배로 줄임")
            else:
                notes.append(f"풀 HP 기준 {label} 효과로 피해가 {multiplier:g}배로 감소함")
        elif kind == "full_hp_endure" and label in triggered:
            if max_hits > 1:
                notes.append(f"{label}은 첫 타격을 버틸 수 있지만 연속 공격의 후속 타격에는 쓰러질 수 있음")
            else:
                notes.append(f"풀 HP 기준 {label} 효과로 1 HP를 남기고 생존함")
                expected = min(expected, max(0.0, max_hp - 1.0))

    # 단일 타격에서 탈/옹골참/기합의띠가 활성화되어 있다면 모든 난수에서 첫 공격 처치를 막는다.
    if max_hits == 1:
        current_hp = max_hp * _hp_fraction(defender_entry, defender_stats)
        guaranteed_endure = any(e.get("kind") == "full_hp_endure" for e in effects) and full_hp and base_max >= current_hp
        disguise_active = any(e.get("kind") == "disguise" for e in effects) and base_max > 0
        if guaranteed_endure or (disguise_active and current_hp > max_hp * 0.125):
            low_blocked = high_blocked = True

    survival_chance = 0.0
    # 기합의머리띠는 확정 생존으로 보지 않고 10% 가능성만 별도 안내한다.
    current_hp_for_chance = max_hp * _hp_fraction(defender_entry, defender_stats)
    for effect in effects:
        if effect.get("kind") == "chance_endure" and max(base_max, base_min) >= current_hp_for_chance:
            survival_chance = max(survival_chance, float(effect.get("chance", 0.0)))
            label = effect.get("labelKo", "기합의머리띠")
            notes.append(f"{label}로 {survival_chance * 100:g}% 확률로 1 HP 생존 가능")
            names.append(label)
            kinds.append("chance_endure")

    return {
        "damage_min": low,
        "damage_max": high,
        "raw_on_hit": max(0.0, expected),
        "kind": "+".join(dict.fromkeys(kinds)),
        "name": "/".join(dict.fromkeys(names)),
        "note": " / ".join(dict.fromkeys(notes)),
        "first_action_ko_blocked": bool(low_blocked and high_blocked),
        "survival_chance": survival_chance,
    }


RECOVERY_MOVES = {
    "Recover", "Roost", "Slack Off", "Soft-Boiled", "Milk Drink",
    "Moonlight", "Morning Sun", "Synthesis", "Shore Up", "Strength Sap",
}
PROTECT_MOVES = {"Protect", "Detect", "King's Shield", "Spiky Shield", "Baneful Bunker", "Silk Trap", "Burning Bulwark"}
SETUP_MOVES = {
    "Swords Dance", "Nasty Plot", "Dragon Dance", "Quiver Dance", "Calm Mind",
    "Bulk Up", "Iron Defense", "Agility", "Rock Polish", "Shell Smash", "Coil",
}
PIVOT_MOVES = {"U-turn", "Volt Switch", "Flip Turn", "Parting Shot", "Chilly Reception", "Baton Pass"}

def status_utility(move: dict) -> float:
    name = move.get("nameEn", "")
    if name in STATUS_MOVE_UTILITY:
        return STATUS_MOVE_UTILITY[name]
    desc = ((move.get("descriptionEn") or "") + " " + (move.get("descriptionKo") or "")).lower()
    if "restores" in desc or "heals" in desc or "회복" in desc:
        return 24
    if "boosts" in desc or "올린" in desc:
        return 20
    if "lowers" in desc or "burn" in desc or "paraly" in desc or "sleep" in desc or "떨어뜨" in desc:
        return 18
    return 8

def contextual_status_utility(move: dict, attacker_entry: dict, attacker_species: dict, attacker_stats: dict,
                              defender_entry: dict, defender_species: dict, defender_stats: dict) -> tuple[float, str, str]:
    """선출 단계에서 변화기의 즉시 운영 가치를 대면 상황에 맞춰 보정한다.

    턴 전체를 확정 예측하지 않고, 기술을 실제로 보유했을 때의 첫 선택 가치만
    보수적으로 평가한다.
    """
    name = move.get("nameEn", "")
    util = float(status_utility(move))
    my_speed = effective_speed(attacker_stats, attacker_entry)
    opp_speed = effective_speed(defender_stats, defender_entry)
    lookup_names = {str(x or "").strip() for x in defender_entry.get("moves", [])}
    lookup_lower = {x.lower() for x in lookup_names}
    opp_has_status = False
    opp_has_recovery_or_setup = False
    # 상대 기술 목록은 영문 입력이 일반적이며, 목록이 없을 때는 과대평가하지 않는다.
    for n in lookup_lower:
        title = n.title()
        if title in RECOVERY_MOVES or title in SETUP_MOVES or title in PROTECT_MOVES:
            opp_has_status = True
            opp_has_recovery_or_setup = True
        elif title in {"Taunt", "Encore", "Thunder Wave", "Will-O-Wisp", "Spore", "Stealth Rock", "Tailwind", "Trick Room"}:
            opp_has_status = True

    if name == "Thunder Wave":
        if not can_receive_status("paralysis", move, defender_entry, defender_species):
            return 0.0, "speed_control", "상대에게 마비가 통하지 않음"
        if my_speed < opp_speed:
            util += 18
            note = "더 빠른 상대의 스피드를 낮춰 다음 행동 순서를 뒤집을 수 있음"
        else:
            util += 5
            note = "마비로 행동 제약을 줄 수 있으나 현재도 내가 느리지 않음"
        return util, "speed_control", note

    if name == "Taunt":
        if opp_has_recovery_or_setup:
            util += 18
            note = "상대의 회복기·랭크업·방어 같은 변화기를 차단할 가치가 큼"
        elif opp_has_status:
            util += 10
            note = "상대의 변화기 사용을 차단할 수 있음"
        else:
            util -= 8
            note = "확인된 상대 변화기가 없어 우선도는 낮음"
        return max(0.0, util), "disruption", note

    if name == "Encore":
        if opp_has_status:
            util += 8
            note = "상대가 변화기를 사용한 뒤 같은 기술에 묶는 운영이 가능함"
        else:
            util -= 5
            note = "직전 기술 정보가 없어 첫 행동 추천보다는 조건부 선택지임"
        return max(0.0, util), "disruption", note

    if name in RECOVERY_MOVES:
        # 상대의 예상 최대 피해를 기술 목록으로 거칠게 추정한다.
        opp_lookup = move_lookup_from_entries(defender_entry, defender_species, defender_stats, attacker_entry, attacker_species, attacker_stats)
        max_frac = max((e.hp_fraction_max for e in opp_lookup if e.category != "변화"), default=0.0)
        if max_frac >= 1.0:
            util -= 18
            note = "한 번에 쓰러질 위험이 있어 회복기를 누를 여유가 적음"
        elif 0 < max_frac <= 0.55:
            util += 14
            note = "상대의 최대 피해를 버티며 체력을 복구해 장기전을 만들 수 있음"
        else:
            note = "상대 피해량을 함께 확인해 회복 타이밍을 판단해야 함"
        return max(0.0, util), "recovery", note

    if name in SETUP_MOVES:
        opp_lookup = move_lookup_from_entries(defender_entry, defender_species, defender_stats, attacker_entry, attacker_species, attacker_stats)
        max_frac = max((e.hp_fraction_max for e in opp_lookup if e.category != "변화"), default=0.0)
        if max_frac >= 1.0:
            util -= 20
            note = "강화 전에 쓰러질 위험이 커서 첫 행동으로는 부적합함"
        elif 0 < max_frac <= 0.45:
            util += 14
            note = "한 번의 공격을 안정적으로 버티며 랭크업할 여지가 있음"
        elif 0 < max_frac <= 0.7:
            util += 6
            note = "강화 기회는 있으나 체력 손실 위험이 있음"
        elif max_frac > 0.7:
            util -= 6
            note = "강화 턴의 피해 부담이 커 조건부 선택지임"
        else:
            note = "상대 피해량을 함께 확인해 강화 기회를 판단해야 함"
        return max(0.0, util), "setup", note

    if name in PROTECT_MOVES:
        util += 2
        return util, "protect", "상대 기술과 메가진화 여부를 확인하거나 턴을 벌 수 있는 안전 선택지"

    return util, "status", "직접 피해 대신 대면 운영을 유리하게 만드는 변화기"

def move_lookup_from_entries(attacker_entry, attacker_species, attacker_stats, defender_entry, defender_species, defender_stats):
    """순환 호출 없이 상대 기술의 대략적인 피해 평가만 만드는 내부 도우미.

    전역 참조 데이터가 없으므로 entry에 임시로 주입된 `_resolvedMoves`가 있을 때만 사용한다.
    현재 일반 호출에서는 빈 목록을 반환해 과대평가를 피한다.
    """
    return []




def _hp_fraction(entry: dict, stats: dict) -> float:
    """현재 HP 정보가 없으면 선출 단계이므로 체력 100%로 본다."""
    if entry.get("currentHp") is not None:
        return max(0.0, min(1.0, float(entry["currentHp"]) / max(1, stats["hp"])))
    if entry.get("currentHpFraction") is not None:
        return max(0.0, min(1.0, float(entry["currentHpFraction"])))
    return 1.0


def _weight_power_target(weight: float) -> int:
    if weight < 10: return 20
    if weight < 25: return 40
    if weight < 50: return 60
    if weight < 100: return 80
    if weight < 200: return 100
    return 120


def _weight_ratio_power(user_weight: float, target_weight: float) -> int:
    ratio = user_weight / max(0.1, target_weight)
    if ratio >= 5: return 120
    if ratio >= 4: return 100
    if ratio >= 3: return 80
    if ratio >= 2: return 60
    return 40


def _low_hp_power(frac: float) -> int:
    # Flail/Reversal 표준 구간을 HP 비율로 근사한다.
    if frac <= 1/48: return 200
    if frac <= 1/5: return 150
    if frac <= 7/20: return 100
    if frac <= 17/48: return 80
    if frac <= 11/16: return 40
    return 20


def resolved_power(move: dict, attacker_entry: dict, attacker_species: dict, attacker_stats: dict,
                   defender_entry: dict, defender_species: dict, defender_stats: dict) -> int:
    rule = move_rules.move_rule(move.get("nameEn", ""))
    kind = rule.get("powerRule")
    base = int(move.get("power", 0) or 0)
    if kind == "target_weight":
        return _weight_power_target(float(defender_species.get("weightKg", 0) or 0))
    if kind == "weight_ratio":
        return _weight_ratio_power(float(attacker_species.get("weightKg", 0) or 0), float(defender_species.get("weightKg", 0) or 0))
    if kind == "slower_speed":
        a = max(1, effective_speed(attacker_stats, attacker_entry))
        d = max(1, effective_speed(defender_stats, defender_entry))
        return max(1, min(150, math.floor(25 * d / a) + 1))
    if kind == "faster_speed":
        ratio = effective_speed(attacker_stats, attacker_entry) / max(1, effective_speed(defender_stats, defender_entry))
        if ratio >= 4: return 150
        if ratio >= 3: return 120
        if ratio >= 2: return 80
        if ratio >= 1: return 60
        return 40
    if kind == "no_item_double":
        return base * 2 if not (attacker_entry.get("item") or "").strip() else base
    if kind == "user_hp_high":
        return max(1, math.floor(150 * _hp_fraction(attacker_entry, attacker_stats)))
    if kind == "target_hp_high":
        return max(1, math.floor(100 * _hp_fraction(defender_entry, defender_stats)))
    if kind == "user_hp_low":
        return _low_hp_power(_hp_fraction(attacker_entry, attacker_stats))
    if kind == "user_status_double":
        return base * 2 if normalized_status(attacker_entry) in {"burn", "paralysis", "poison", "bad_poison"} else base
    if kind == "target_status_double":
        return base * 2 if has_major_status(defender_entry) else base
    if kind == "target_poison_double":
        return base * 2 if normalized_status(defender_entry) in {"poison", "bad_poison"} else base
    return base


def expected_hit_multiplier(move: dict, attacker_entry: dict, accuracy_factor: float = 1.0) -> float:
    rule = move_rules.move_rule(move.get("nameEn", ""))
    hit_rule = rule.get("hitRule")
    if hit_rule == "two_hits":
        return 2.0
    if hit_rule == "two_to_five":
        # 스킬링크는 최대 타수, 그 외 표준 확률의 평균 3.1타.
        return 5.0 if ability_key(attacker_entry.get("ability", "")) == "Skill Link" else 3.1
    if hit_rule == "population_bomb":
        # 첫 타격의 명중률은 일반 정확도 보정에서 이미 한 번 곱해진다.
        # 따라서 여기서는 1 + p + ... + p^9를 반환해 최대 10회의 기대 타수를 만든다.
        p = max(0.0, min(1.0, accuracy_factor))
        return sum(p ** i for i in range(10))
    return 1.0


def fixed_damage(move: dict, attacker_entry: dict, attacker_stats: dict, defender_entry: dict, defender_stats: dict):
    rule = move_rules.move_rule(move.get("nameEn", ""))
    if "fixedDamage" in rule:
        return float(rule["fixedDamage"])
    kind = rule.get("fixedDamageRule")
    user_hp = _hp_fraction(attacker_entry, attacker_stats) * attacker_stats["hp"]
    target_hp = _hp_fraction(defender_entry, defender_stats) * defender_stats["hp"]
    if kind == "half_target_current_hp":
        return max(1.0, target_hp / 2)
    if kind == "target_minus_user_hp":
        return max(0.0, target_hp - user_hp)
    if kind == "user_current_hp":
        return max(0.0, user_hp)
    return None

def evaluate_move(move: dict, attacker_entry: dict, attacker_species: dict, attacker_stats: dict,
                  defender_entry: dict, defender_species: dict, defender_stats: dict,
                  attacker_intimidated: bool = False) -> MoveEval:
    category = move.get("category", "변화")
    if category == "변화" or not move.get("power"):
        util, operation_kind, operation_note = contextual_status_utility(
            move, attacker_entry, attacker_species, attacker_stats,
            defender_entry, defender_species, defender_stats
        )
        rule = move_rules.move_rule(move.get("nameEn", ""))
        inflicted = rule.get("statusInflict")
        if inflicted and not can_receive_status(inflicted, move, defender_entry, defender_species):
            util = 0.0
            operation_note = "상대의 타입·특성 때문에 이 상태이상이 통하지 않음"
        elif (ability_key(defender_entry.get("ability", "")) == "Good as Gold"
                and status_move_targets_defender(move)):
            util = 0.0
            operation_note = "황금몸 특성 때문에 상대를 대상으로 하는 변화기가 통하지 않음"
        return MoveEval(move.get("nameEn", ""), category, 0, move.get("accuracy", 100), 1.0, 1.0,
                        0.0, 0.0, util, move.get("priority", 0), operation_kind=operation_kind,
                        operation_note=operation_note)

    rule = move_rules.move_rule(move.get("nameEn", ""))
    atk_key, def_key = ("atk", "def") if category == "물리" else ("spa", "spd")
    atk_key = rule.get("attackStat", atk_key)
    atk = staged_stat(attacker_stats, attacker_entry, atk_key)
    defense = max(1, staged_stat(defender_stats, defender_entry, def_key))
    if category == "물리" and attacker_intimidated:
        atk *= 2 / 3
    if (category == "물리" and normalized_status(attacker_entry) == "burn"
            and not rule.get("ignoresBurnAttackDrop")
            and ability_key(attacker_entry.get("ability", "")) != "Guts"):
        atk *= 0.5

    move_type = move.get("type", "Normal")
    mult = effective_type_multiplier(move_type, defender_species.get("types", []), defender_entry.get("ability", ""))
    stab = 1.5 if move_type in attacker_species.get("types", []) else 1.0
    accuracy = move.get("accuracy", 100)
    no_guard = "No Guard" in {
        ability_key(attacker_entry.get("ability", "")),
        ability_key(defender_entry.get("ability", "")),
    }
    accuracy_factor = 1.0 if no_guard or accuracy in (0, 101, None) else max(
        0.5, min(1.0, (accuracy / 100) * move_accuracy_multiplier(
            attacker_entry.get("item", ""), defender_entry.get("item", "")
        ))
    )
    item_mult = offensive_item_multiplier(attacker_entry.get("item", ""), category, move_type, mult)
    item_def_mult = defensive_item_multiplier(defender_entry.get("item", ""), move_type, mult)
    ability_mult = offensive_ability_multiplier(attacker_entry.get("ability", ""), move_type)
    field_mult = field_move_multiplier(move_type, attacker_entry, attacker_species, defender_entry)

    fixed = fixed_damage(move, attacker_entry, attacker_stats, defender_entry, defender_stats)
    power = resolved_power(move, attacker_entry, attacker_species, attacker_stats,
                           defender_entry, defender_species, defender_stats)
    hit_mult = expected_hit_multiplier(move, attacker_entry, accuracy_factor)
    min_hits, max_hits = _hit_bounds(rule)

    if fixed is not None:
        # 고정 피해는 일반 방어·자속·멀티스케일 보정을 받지 않지만 탈/생존 효과는 적용될 수 있다.
        on_hit = 0.0 if mult == 0 else fixed
        base_min = base_max = on_hit
        per_hit_min = per_hit_max = on_hit
        raw_on_hit = on_hit
        direct_damage = True
    else:
        base = (((2 * 50 / 5 + 2) * power * atk / defense) / 50 + 2)
        common = base * stab * mult * item_mult * item_def_mult * ability_mult * field_mult
        per_hit_min = common * 0.85
        per_hit_max = common * 1.00
        base_min = per_hit_min * min_hits
        base_max = per_hit_max * max_hits
        raw_on_hit = common * 0.925 * hit_mult
        direct_damage = False

    opening = _apply_opening_effects(
        base_min=base_min,
        base_max=base_max,
        per_hit_min=per_hit_min,
        per_hit_max=per_hit_max,
        raw_on_hit=raw_on_hit,
        min_hits=min_hits,
        max_hits=max_hits,
        expected_hits=hit_mult,
        defender_entry=defender_entry,
        defender_stats=defender_stats,
        attacker_entry=attacker_entry,
        direct_damage=direct_damage,
    )
    damage_min = opening["damage_min"]
    damage_max = opening["damage_max"]
    raw = opening["raw_on_hit"] * accuracy_factor

    hp_total = max(1, defender_stats["hp"])
    hp_fraction = raw / hp_total
    hp_fraction_min = damage_min / hp_total
    hp_fraction_max = damage_max / hp_total
    base_hp_fraction_min = base_min / hp_total
    base_hp_fraction_max = base_max / hp_total

    # 선출 평가에서 우선기는 실제 피해 외에도 행동 보장 가치를 조금 가진다.
    priority = move.get("priority", 0) or 0
    utility = min(140.0, hp_fraction * 100) + max(0, priority) * 5
    operation_kind = ""
    operation_note = ""
    move_name = move.get("nameEn", "")
    if priority > 0:
        if effective_speed(attacker_stats, attacker_entry) < effective_speed(defender_stats, defender_entry):
            utility += 10.0
            operation_note = "상대가 더 빨라도 선공기로 먼저 행동할 수 있음"
        else:
            operation_note = "선공기로 약해진 상대를 마무리하기 쉬움"
        operation_kind = "priority"
    if move_name in PIVOT_MOVES:
        operation_kind = "pivot"
        # 내가 더 빠르면 상대가 움직이기 전에 교체가 끝나서, 그 턴 상대 공격은 방금 들어온
        # 후속 포켓몬이 그대로 받는다 - "안전한 투입"이 아니라 오히려 노출이다. 내가 더 느리면
        # 상대는 이미 그 턴 행동을 다 썼으므로 교체로 들어오는 포켓몬은 이번 턴 위험이 없다.
        if effective_speed(attacker_stats, attacker_entry) > effective_speed(defender_stats, defender_entry):
            utility += 2.0
            operation_note = "내가 더 빨라 상대보다 먼저 교체하지만, 그만큼 후속 포켓몬이 상대의 이번 턴 공격에 그대로 노출됨"
        else:
            utility += 8.0
            operation_note = "공격 후 교체해 불리한 대면을 끊고, 상대가 이미 행동을 마친 뒤라 후속 포켓몬을 안전하게 투입할 수 있음"
    secondary_status = rule.get("secondaryStatus")
    secondary_chance = float(rule.get("secondaryChance", 0) or 0) / 100.0
    if secondary_status and secondary_chance > 0:
        if secondary_status == "random_major_status":
            utility += 8.0 * secondary_chance
        elif can_receive_status(secondary_status, move, defender_entry, defender_species):
            utility += {"burn": 18.0, "paralysis": 16.0, "poison": 10.0}.get(secondary_status, 8.0) * secondary_chance

    return MoveEval(
        move.get("nameEn", ""), category, int(power), int(accuracy or 100),
        mult, stab, raw, hp_fraction, utility, priority,
        damage_min, damage_max, hp_fraction_min, hp_fraction_max, accuracy_factor,
        base_min, base_max, base_hp_fraction_min, base_hp_fraction_max,
        opening["kind"], opening["name"], opening["note"],
        opening["first_action_ko_blocked"], opening["survival_chance"],
        min_hits, max_hits, operation_kind, operation_note,
    )

def best_action(attacker_entry, attacker_species, attacker_stats, defender_entry, defender_species,
                defender_stats, refdata, attacker_intimidated=False):
    lookup = move_lookup(refdata)
    evaluations = []
    for name in attacker_entry.get("moves", []):
        move = lookup.get(move_rules.normalize_move_name(name or ""))
        if move:
            evaluations.append(evaluate_move(move, attacker_entry, attacker_species, attacker_stats,
                                             defender_entry, defender_species, defender_stats,
                                             attacker_intimidated))
    if not evaluations:
        return None, []
    damaging = [e for e in evaluations if e.category != "변화"]
    status = [e for e in evaluations if e.category == "변화"]
    best_damage = max(damaging, key=lambda e: e.utility) if damaging else None
    best_status = max(status, key=lambda e: e.utility) if status else None
    # 변화기는 실제 대면에서 공격보다 충분히 가치가 높을 때만 첫 추천으로 올린다.
    # 확정 처치 가능한 공격기가 있으면 항상 공격을 우선한다.
    if best_damage and best_damage.hp_fraction_min >= 1.0 and not best_damage.first_action_ko_blocked:
        return best_damage, evaluations
    if best_status and (not best_damage or best_status.utility >= max(30.0, best_damage.utility + 8.0)):
        return best_status, evaluations
    if best_damage:
        return best_damage, evaluations
    return best_status, evaluations


def survival_bonus(entry: dict) -> float:
    item_bonus = float(battle_rules.item_rule(entry.get("item", "")).get("survivalBonus", 0.0))
    ability_bonus = float(battle_rules.ability_rule(entry.get("ability", "")).get("survivalBonus", 0.0))
    return max(item_bonus, ability_bonus)


def speed_item_multiplier(item: str) -> float:
    return float(battle_rules.item_rule(item).get("speedMultiplier", 1.0))


def effective_speed(stats: dict, entry: dict) -> int:
    speed = staged_stat(stats, entry, "spe") * speed_item_multiplier(entry.get("item", ""))
    if normalized_status(entry) == "paralysis":
        speed *= 0.5
    return int(speed)


def matchup_score(my_best: MoveEval | None, opp_best: MoveEval | None, my_entry: dict, opp_entry: dict,
                  my_speed: int, opp_speed: int, record_bonus: float) -> float:
    my_value = my_best.utility if my_best else 0.0
    opp_value = opp_best.utility if opp_best else 0.0
    # 피해율 차이가 주축. 생존 보장, 스피드, 과거 전적은 보조 요소다.
    score = (my_value - opp_value) / 25.0
    score += survival_bonus(my_entry) / 25.0
    score -= survival_bonus(opp_entry) / 30.0
    if my_speed > opp_speed:
        score += 0.45
    elif my_speed < opp_speed:
        score -= 0.45
    score += record_bonus
    return score


def defensive_weaknesses(species: dict, ability: str = "") -> set[str]:
    weak = set()
    for atk_type in type_chart.ALL_TYPES:
        if effective_type_multiplier(atk_type, species.get("types", []), ability) > 1:
            weak.add(atk_type)
    return weak


def combo_synergy_adjustment(combo, my_party, species_list) -> tuple[float, list[str]]:
    """약점 중복, 공격 역할 중복, 메가스톤 충돌을 감점한다."""
    adjustment = 0.0
    notes = []
    weakness_counts = {}
    physical = special = 0
    mega_count = 0
    for i in combo:
        entry, species = my_party[i], species_list[i]
        if not species:
            continue
        for t in defensive_weaknesses(species, entry.get("ability", "")):
            weakness_counts[t] = weakness_counts.get(t, 0) + 1
        item = item_key(entry.get("item", ""))
        if "ite" in item:
            mega_count += 1
        # 종족값과 기술 분류로 주 역할을 거칠게 판정
        if species["baseStats"]["atk"] >= species["baseStats"]["spa"]:
            physical += 1
        else:
            special += 1

    overlaps = sorted(t for t, n in weakness_counts.items() if n >= 3)
    if overlaps:
        adjustment -= 0.55 * len(overlaps)
        notes.append("세 마리 모두가 공유하는 약점: " + ", ".join(overlaps))
    if physical == len(combo) or special == len(combo):
        adjustment -= 0.35
        notes.append("공격 역할이 한쪽으로 치우침")
    if mega_count >= 2:
        adjustment -= 0.65 * (mega_count - 1)
        notes.append("메가스톤 보유 포켓몬이 여러 마리라 한 마리만 메가진화 가능")
    return adjustment, notes
